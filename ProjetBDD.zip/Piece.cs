﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetBDD
{
    public class Piece
    {
        string numero;
        int stock;
        int prix;
        public Piece(string numero, int stock, int prix)
        {
            this.numero = numero;
            this.stock = stock;
            this.prix = prix;
        }

        public Piece()
        {
            this.numero = null;
            this.stock = 0;
            this.prix = 0;
        }

        public string Numero
        {
            get { return this.numero; }
            set { this.numero = value; }
        }
        public int Stock
        {
            get { return this.stock; }
            set { this.stock = value; }
        }
        public int Prix
        {
            get { return prix; }
            set { prix = value; }
        }
    }
}

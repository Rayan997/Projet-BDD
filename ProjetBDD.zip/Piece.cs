﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetBDD
{
    class Piece
    {
        string numero;
        int stock;

        public Piece(string numero,int stock)
        {
            this.numero = numero;
            this.stock = stock;
        }

        public string Numero 
        {
            get { return this.numero; }
        }
        public int Stock
        {
            get { return this.stock; }
            set {this.stock = value; }
        }
        public override string ToString()
        {
            return this.numero+"nombre :" + this.stock;
        }
    }
}

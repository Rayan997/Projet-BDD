﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetBDD
{
    public class Commande
    {
        private string numeroCommande;
        private List<Piece> listePiece;
        private List<Velo> listeVelo;

        public Commande(string numeroCommande, List<Piece> listePiece, List<Velo> listeVelo)
        {
            this.numeroCommande = numeroCommande;
            this.listePiece = listePiece;
            this.listeVelo = listeVelo;
        }

        public Commande(string numeroCommande, List<Piece> listePiece)
        {
            this.numeroCommande = numeroCommande;
            this.listePiece = listePiece;
            this.listeVelo = null;
        }

        public Commande(string numeroCommande, List<Velo> listeVelo)
        {
            this.numeroCommande = numeroCommande;
            this.listePiece = null;
            this.listeVelo = listeVelo;
        }

        public Commande(string numeroCommande)
        {
            this.numeroCommande = numeroCommande;
            this.listePiece = null;
            this.listeVelo = null;
        }

        public Commande()
        {
            this.numeroCommande = null;
            this.listePiece = null;
            this.listeVelo = null;
        }

        public string NumeroCommande
        {
            get { return this.numeroCommande; }
            set { this.numeroCommande = value; }
        }

        public List<Piece> ListePiece
        {
            get { return this.listePiece; }
            set { this.listePiece = value; }
        }
        public List<Velo> ListeVelo
        {
            get { return this.listeVelo; }
            set { this.listeVelo = value; }
        }

        /// <summary>
        /// Calcul le prix d'une commande
        /// </summary>
        /// <returns>Retourne le prix de la commande en instance</returns>
        public double PrixCommande()
        {
            double res = 0;
            foreach (Piece p in listePiece)
            {
                res += p.Prix;
            }
            foreach (Velo v in listeVelo)
            {
                res += v.Prix;
            }
            return res;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetBDD
{
    class Velo
    {
        int numModel;
        int stock;
        public Velo(int numModel,int stock)
        {
            this.numModel = numModel;
            this.stock = stock;
        }

        public int NumModel
        {
            get { return numModel; }
        }

        public int Stock
        {
            get { return stock; }
            set { stock = value; }
        }
    }
}

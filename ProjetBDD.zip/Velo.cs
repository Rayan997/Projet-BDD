﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetBDD
{
    public class Velo
    {
        int numModel;
        int stock;
        int prix;
        public Velo(int numModel,int stock, int prix)
        {
            this.numModel = numModel;
            this.stock = stock;
            this.prix = prix;
        }

        public Velo()
        {
            this.numModel = 0;
            this.stock = 0;
            this.prix = 0;
        }

        public Velo(int numModel)
        {
            this.numModel = numModel;
            this.stock = 0;
            this.prix = 0;
        }

        public int NumModel
        {
            get { return numModel; }
        }

        public int Stock
        {
            get { return stock; }
            set { stock = value; }
        }

        public int Prix
        {
            get { return prix; }
            set { prix = value; }
        }
    }
}

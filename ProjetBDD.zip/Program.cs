﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetBDD
{
    using MySql.Data.MySqlClient;
    using System.IO;

    class Program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("Bonjour !");
            Console.WriteLine("");
            Console.WriteLine("------------------------------");
            Console.WriteLine("Saisir identifiant :");
            string id = Console.ReadLine();
            Console.WriteLine("Saisir mot de passe :");
            string mdp = Console.ReadLine();
            //string connectionString = "SERVER=localhost;PORT=3306;DATABASE=velomax;UID="+id +";PASSWORD="+mdp+";SSLMODE=none;";
            string connectionString = "SERVER=localhost;PORT=3306;DATABASE=velomax;UID=" + "root" + ";PASSWORD=" + "CourbevoieESILV.2020" + ";SSLMODE=none;";
            MySqlConnection connection = new MySqlConnection(connectionString);

            int nombre;
            int nb;

            Console.WriteLine("Bienvenue !");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            bool test = true;
            while (test == true)
            {
                Console.WriteLine("Saisir 1 pour consulter la gestion du stock");
                Console.WriteLine("Saisir 2 pour avoir des informations générales sur Velomax");
                Console.WriteLine("Saisir 3 pour gérer les fournisseurs");
                Console.WriteLine("Saisir 4 pour gérer les pièces détachées");
                Console.WriteLine("Saisir 5 pour gérer les vélos");
                Console.WriteLine("Saisir 6 pour gérer les clients");
                nombre = int.Parse(Console.ReadLine());
                switch (nombre)
                {
                    #region Cas 1 : Consulter la gestion du stock
                    case 1:
                        {
                            Console.Clear();
                            Console.WriteLine("------------------");
                            RuptureDeStock(connection);                            
                            Console.WriteLine("------------------");
                            Console.WriteLine("Saisir 1 pour avoir un aperçu des stocks par pièce");
                            Console.WriteLine("Saisir 2 pour avoir un aperçu des stocks par fournisseur");
                            Console.WriteLine("Saisir 3 pour avoir un aperçu des stocks par vélo");
                            Console.WriteLine("Saisir 4 pour avoir un aperçu des stocks par catégorie de vélo");
                            Console.WriteLine("Saisir 5 pour avoir un aperçu des stocks par grandeur");
                            Console.WriteLine("Saisir 6 pour avoir un aperçu des stocks par prix unitaire");
                            Console.WriteLine("Saisir un autre nombre pour revenir à l'accueil");
                            nb = int.Parse(Console.ReadLine());
                            switch (nb)
                            {
                                case 1:
                                    {
                                        parPiece(connection);
                                        break;
                                    }
                                case 2:
                                    {
                                        parFournisseur(connection);
                                        break;
                                    }
                                case 3:
                                    {
                                        parVelo(connection);
                                        break;
                                    }
                                case 4:
                                    {
                                        parCategorieVelo(connection);
                                        break;
                                    }
                                case 5:
                                    {
                                        parGrandeur(connection);
                                        break;
                                    }
                                case 6:
                                    {
                                        parPrixUnitaire(connection);
                                        break;
                                    }
                                default:
                                    { Console.WriteLine(""); break; }
                            }
                            break;
                        }
                    #endregion

                    #region Cas 2 : Information général sur Velomax
                    case 2:
                        {
                            Console.Clear();
                            Console.WriteLine("Nombre de client");
                            Console.WriteLine("=================");
                            NombreClient(connection);
                            Console.WriteLine("\nappuyez sur une touche pour continuer");
                            Console.ReadKey();

                            Console.Clear();
                            Console.WriteLine("\n\nListe des membres par programme d’adhésion");
                            Console.WriteLine("=================");
                            ListeMembrePourChaqueProgramme(connection);
                            Console.WriteLine("\nappuyez sur une touche pour continuer");
                            Console.ReadKey();

                            /*Console.Clear();
                            Console.WriteLine("\n\n1.3 Liste des véhicules par prix de journée décroissant");
                            Console.WriteLine("=================");
                            //Exo3(connection);
                            Console.WriteLine("\nappuyez sur une touche pour continuer");
                            Console.ReadKey();

                            Console.Clear();
                            Console.WriteLine("\n\n1.4 Valeur moyenne des prix de journée");
                            Console.WriteLine("=================");
                            //Exo4(connection);
                            Console.WriteLine("\nappuyez sur une touche pour continuer");
                            Console.ReadKey();

                            Console.Clear();
                            Console.WriteLine("\n\n1.6 deuxième prix de journée minimum");
                            Console.WriteLine("\n=================");
                            //Exo6(connection);
                            Console.WriteLine("appuyez sur une touche pour continuer");
                            Console.ReadKey();
                            Console.WriteLine("\n1.6 deuxième prix de journée minimum version 2");
                            Console.WriteLine("\n=================");


                            Console.Clear();
                            Console.WriteLine("\n\n1.7 prix de journée médian");
                            Console.WriteLine("\n=================");
                            //Exo7(connection);
                            Console.WriteLine("appuyez sur une touche pour finir\n");

                            Console.Clear();
                            Console.WriteLine("\n\n1.7 prix de journée médian");
                            Console.WriteLine("\n=================");
                            //Exo8(connection);
                            Console.WriteLine("appuyez sur une touche pour finir\n");
                            Console.ReadKey();*/
                            break;
                        }
                    #endregion

                    #region Cas 3 : Gestion fournisseur
                    case 3:
                        {
                            Console.Clear();
                            Console.WriteLine("Saisir 1 pour ajouter un fournisseur");
                            Console.WriteLine("Saisir 2 pour afficher les fournisseurs");
                            Console.WriteLine("Saisir 3 pour mettre à jour un fournisseur");
                            Console.WriteLine("Saisir 4 pour suprimer un fournisseur");
                            int nb2 = Convert.ToInt32(Console.ReadLine());
                            switch(nb2)
                            {
                                case 1:
                                    CreationFournisseur(connection);
                                    break;
                                case 2:
                                    AffichageFournisseur(connection);
                                    break;
                                case 3:
                                    MiseAJourFournisseur(connection);
                                    break;
                                case 4:
                                    SuppressionFournisseur(connection);
                                    break;
                                default:
                                    { Console.WriteLine("Choix indisponible"); break; }
                            }


                            break;
                        }
                    #endregion

                    #region Cas 4 : Gestion des Pièces détachés
                    case 4:
                        Console.Clear();
                        Console.WriteLine("Saisir 1 pour afficher les pièces détachées");
                        Console.WriteLine("Saisir 2 pour supprimer une pièce");
                        Console.WriteLine("Saisir 3 pour modifier une pièce");
                        Console.WriteLine("Saisir 4 pour créer une pièce");
                        int nb3 = Convert.ToInt32(Console.ReadLine());
                        switch(nb3)
                        {
                            case 1:
                                AffichagePiece(connection);
                                break;
                            case 2:
                                SuppressionPiece(connection);
                                break;
                            case 3:
                                ModificationPiece(connection);
                                break;
                            case 4:
                                CreationPiece(connection);
                                break;
                            default:
                                { Console.WriteLine("Choix indisponible"); break; }
                        }
                        break;
                    #endregion

                    #region Cas 5 : Gestion des vélos
                    case 5:
                        Console.Clear();
                        Console.WriteLine("Saisir 1 pour afficher les vélos");
                        Console.WriteLine("Saisir 2 pour créer un vélos");
                        Console.WriteLine("Saisir 3 pour modifier un vélos");
                        Console.WriteLine("Saisir 4 pour supprimer un vélos");
                        int nb4 = Convert.ToInt32(Console.ReadLine());
                        switch(nb4)
                        {
                            case 1:
                                AffichageVelos(connection);
                                break;
                            case 2:
                                CreerVelo(connection);
                                break;
                            case 3:
                                ModificationVelo(connection);
                                break;
                            case 4:
                                SuppressionVelo(connection);
                                break;
                            default:
                                { Console.WriteLine("Choix indisponible"); break; }
                        }
                        
                        break;
                    #endregion

                    #region Cas 6 : Gestion clients
                    case 6:
                        Console.Clear();
                        CreationClient(connection);
                        break;
                    #endregion
                    default:
                        { Console.WriteLine("Choix indisponible"); break; }
                }
                Console.WriteLine("Voulez-vous revenir à l'écran d'accueil? ( true ou false )");
                test = Convert.ToBoolean(Console.ReadLine());
                if (test)
                {
                    Console.Clear();
                }
            }

            

            Console.ReadKey();

        }//main

        static void Exo0()
        {
            //lire le fichier clients.csv
            Console.WriteLine("Lecture du fichier clients.csv");
            Console.WriteLine("----------------------------");
            string nomFichier = "clients.csv";
            Lire(nomFichier);
            Console.WriteLine("----------------------------");
            Console.WriteLine("Appuyez sur une touche pour continuer...\n");
            Console.ReadKey();
            //
            // ecrire dans le fichier csv
            // le client supplémentaire
            Console.WriteLine("Ecriture dans le fichier clients.csv");
            Console.WriteLine("----------------------------");
            string nom = "Jouvet";
            string prenom = "Louis";
            int age = 80;
            string numPermis = "55555";
            string adresse = "rue du vent";
            string ville = "Paris";
            string newClient = nom + ";"
                + prenom + ";"
                + Convert.ToString(age) + ";"
                + numPermis + ";"
                + adresse + ";"
                + ville;
            bool append = true;
            Ecrire(newClient, nomFichier, append);

            //relire le fichier clients.csv
            Console.WriteLine("Relecture du fichier clients.csv");
            Console.WriteLine("----------------------------");
            Lire(nomFichier);
            Console.WriteLine("----------------------------\n");

        }
        static void Ecrire(string ligne, string fichier, bool append)
        {
            StreamWriter ecrire = new StreamWriter(fichier, true);
            ecrire.WriteLine(ligne);
            ecrire.Close();
        }
        static void Lire(string fichier)
        {
            string ligne = "";
            char[] sep = new char[1] { '1' };
            string[] datas = new string[6];

            StreamReader lecteur = new StreamReader(fichier);
            while (lecteur.Peek() > 0)
            {
                ligne = lecteur.ReadLine();
                Console.WriteLine("ligne lu " + ligne);
                datas = ligne.Split(';');
                //datas = ligne.Split(sep);
            }
            lecteur.Close();
        }



        static void parPiece(MySqlConnection connection)
        //Gestion des stocks par pièce
        {
            connection.Open();
            List<Piece> pieces = LectureStock();
            MySqlCommand command = connection.CreateCommand();
            command.CommandText =
                "SELECT description , count(*) as Nombre "
                + "FROM Piece_rechange p "
                + "GROUP BY p.description;";
            //" SELECT DISTINCT(marque) FROM voiture ;";

            MySqlDataReader reader;
            reader = command.ExecuteReader();

            string description;
            int Nombre = 0;

            while (reader.Read())// parcours ligne par ligne
            {
                // prix = Convert.ToInt32(Console.ReadLine());
                description = reader.GetString(0);  // récupération de la 1ère colonne (il n'y en a qu'une dans la requête !)
                Nombre = reader.GetInt32(1);
                //Console.WriteLine(marque);
                Console.WriteLine(description + " : " + Nombre +" modeles différents");
            }

            connection.Close();

            connection.Open();

            Console.WriteLine("Pour quel pièce souhaitez-vous connaitre plus de détails ? ( cadre, guidon, freins, selle, derailleur avant, derailleur arrière, roue arrière, reflecteurs, pedalier, ordinateur, panier)");
            string piece = Console.ReadLine();
            command = connection.CreateCommand();
            command.CommandText =
                "SELECT * "
                + "FROM Piece_rechange p "
                + "WHERE p.description = '" + piece + "';";

            reader = command.ExecuteReader();

            string numeroProduit;
            string date_intro;
            string date_discont_prod;
            int delai_approvisionnement;
            string numero_produit_fournisseur;
            string siretFournisseur;
            int stock;
            int prix;
            


            while (reader.Read())// parcours ligne par ligne
            {
                // prix = Convert.ToInt32(Console.ReadLine());
                numeroProduit = reader.GetString(0);
                description = reader.GetString(1);
                date_intro = reader.GetString(2);
                date_discont_prod = reader.GetString(3);
                delai_approvisionnement = reader.GetInt32(4);
                numero_produit_fournisseur = reader.GetString(5);
                siretFournisseur = reader.GetString(6);
                stock = 0;
                prix = 0;
                foreach(Piece p in pieces)
                {
                    if(p.Numero==numeroProduit)
                    {
                        stock = p.Stock;
                        prix = p.Prix;
                    }
                }
                //Console.WriteLine(marque);
                Console.WriteLine(numeroProduit + " : " + description + " , " + date_intro + " , " + date_discont_prod + " , " + delai_approvisionnement + " , " + numero_produit_fournisseur + " , " + siretFournisseur+" ; "+stock +" ; " +prix+" euros" );
            }



            connection.Close();
        }

        /*static void RuptureDeStock(MySqlConnection connection)
        {
            //Liste contenant les numéro de produit des pièces de vélomax
            List<string> liste_Piece_Disponible = new List<string>();
            List<string> liste_Piece_Necessaire = new List<string>();
           
            connection.Open();

            MySqlCommand command = connection.CreateCommand();
            command.CommandText = "SELECT numeroProduit "
                                + "FROM Piece_rechange p;";

            MySqlDataReader reader;
            reader = command.ExecuteReader();

            string numeroProduit;

            while (reader.Read())   // parcours ligne par ligne
            {
                numeroProduit = reader.GetString(0); // récupération 1ère colonne
                liste_Piece_Disponible.Add(numeroProduit);

                Console.WriteLine(numeroProduit);
            }

            connection.Close();

            //Cadre
            liste_Piece_Necessaire.Add("C32");
            liste_Piece_Necessaire.Add("C34");
            liste_Piece_Necessaire.Add("C76");
            liste_Piece_Necessaire.Add("C43");
            liste_Piece_Necessaire.Add("C44f");
            liste_Piece_Necessaire.Add("C43f");
            liste_Piece_Necessaire.Add("C01");
            liste_Piece_Necessaire.Add("C02");
            liste_Piece_Necessaire.Add("C15");
            liste_Piece_Necessaire.Add("C87");
            liste_Piece_Necessaire.Add("C87f");
            liste_Piece_Necessaire.Add("C25");
            liste_Piece_Necessaire.Add("C26");

            //Guidon
            liste_Piece_Necessaire.Add("G7");
            liste_Piece_Necessaire.Add("G9");
            liste_Piece_Necessaire.Add("G12");

            //Freins
            liste_Piece_Necessaire.Add("F3");
            liste_Piece_Necessaire.Add("F3");

            //Selle
            liste_Piece_Necessaire.Add("S88");
            liste_Piece_Necessaire.Add("S37");
            liste_Piece_Necessaire.Add("S35");
            liste_Piece_Necessaire.Add("S02");
            liste_Piece_Necessaire.Add("S03");
            liste_Piece_Necessaire.Add("S36");
            liste_Piece_Necessaire.Add("S34");
            liste_Piece_Necessaire.Add("S87");

            //Dérailleurs Avant
            liste_Piece_Necessaire.Add("DV133");
            liste_Piece_Necessaire.Add("DV132");
            liste_Piece_Necessaire.Add("DV17");
            liste_Piece_Necessaire.Add("DV87");
            liste_Piece_Necessaire.Add("DV57");
            liste_Piece_Necessaire.Add("DV15");
            liste_Piece_Necessaire.Add("DV41");

            //Dérailleurs Arrière
            liste_Piece_Necessaire.Add("DR56");
            liste_Piece_Necessaire.Add("DR87");
            liste_Piece_Necessaire.Add("DR86");
            liste_Piece_Necessaire.Add("DR23");
            liste_Piece_Necessaire.Add("DR76");
            liste_Piece_Necessaire.Add("DR52");

            //Roue
            liste_Piece_Necessaire.Add("R1");
            liste_Piece_Necessaire.Add("R2");
            liste_Piece_Necessaire.Add("R11");
            liste_Piece_Necessaire.Add("R12");
            liste_Piece_Necessaire.Add("R18");
            liste_Piece_Necessaire.Add("R19");
            liste_Piece_Necessaire.Add("R32");
            liste_Piece_Necessaire.Add("R44");
            liste_Piece_Necessaire.Add("R45");
            liste_Piece_Necessaire.Add("R46");
            liste_Piece_Necessaire.Add("R47");
            liste_Piece_Necessaire.Add("R48");

            //Réflecteurs
            liste_Piece_Necessaire.Add("R02");
            liste_Piece_Necessaire.Add("R09");
            liste_Piece_Necessaire.Add("R10");

            //Pédalier
            liste_Piece_Necessaire.Add("P12");
            liste_Piece_Necessaire.Add("P34");
            liste_Piece_Necessaire.Add("P1");
            liste_Piece_Necessaire.Add("P15");

            //Ordinateur
            liste_Piece_Necessaire.Add("O2");
            liste_Piece_Necessaire.Add("O4");

            //Panier
            liste_Piece_Necessaire.Add("S01");
            liste_Piece_Necessaire.Add("S05");
            liste_Piece_Necessaire.Add("S74");
            liste_Piece_Necessaire.Add("S73");


            List<string> liste_Piece_A_Acheter = liste_Piece_Necessaire;

            foreach (string piece in liste_Piece_Disponible)
                liste_Piece_A_Acheter.Remove(piece);
            Console.WriteLine("Attention, " + liste_Piece_A_Acheter.Count + " pièces de sont pas disponible");
            Console.WriteLine("Voici les pièces en rupture de stock");
            foreach (string piece in liste_Piece_A_Acheter)
                Console.WriteLine(piece);

            Console.WriteLine("Nous vous suggérons d'aller vous approvisionner chez l'un de vos fournisseurs");





        }*/

        static void RuptureDeStock(MySqlConnection connection)
        {
            List<Piece> pieces = LectureStock();
            foreach(Piece p in pieces)
            {
                if(p.Stock==0)
                {
                    Console.WriteLine(p.Numero + " est en ruptur de stock");
                }
            }
        }
        static void parFournisseur(MySqlConnection connection)
        //Gestion des stocks par fournisseur
        {
            connection.Open();
            List<Piece> pieces = LectureStock();
            MySqlCommand command = connection.CreateCommand();
            command.CommandText =
                "SELECT f.nomEntreprise , count(*) as Nombre_de_pieces_differentes_venant_de_ce_fourisseur "
                + "FROM Piece_rechange p NATURAL JOIN fournisseur f "
                + "GROUP BY p.siretFournisseur;";

            MySqlDataReader reader;
            reader = command.ExecuteReader();

            string nomEntreprise;
            int Nombre = 0;

            while (reader.Read())// parcours ligne par ligne
            {
                // prix = Convert.ToInt32(Console.ReadLine());
                nomEntreprise = reader.GetString(0);  // récupération de la 1ère colonne (il n'y en a qu'une dans la requête !)
                Nombre = reader.GetInt32(1);
                //Console.WriteLine(marque);
                Console.WriteLine(nomEntreprise + " : " + Nombre);
            }

            connection.Close();

            connection.Open();

            Console.WriteLine("Pour quel fournisseur souhaitez-vous connaitre plus de détails ? (Saisir son nom)");
            string fournisseur = Console.ReadLine();
            command = connection.CreateCommand();
            command.CommandText =
                "SELECT * "
                + "FROM Piece_rechange p, fournisseur f "
                + "WHERE p.siretFournisseur = f.siretFournisseur and f.nomEntreprise = '" + fournisseur + "';";

            reader = command.ExecuteReader();

            string numeroProduit;
            string description;
            string date_intro;
            string date_discont_prod;
            int delai_approvisionnement;
            string numero_produit_fournisseur;
            string siretFournisseur;
            string contact;
            string adresse;
            string libelle;
            int stock;




            while (reader.Read())// parcours ligne par ligne
            {
                numeroProduit = reader.GetString(0);
                description = reader.GetString(1);
                date_intro = reader.GetString(2);
                date_discont_prod = reader.GetString(3);
                delai_approvisionnement = reader.GetInt32(4);
                numero_produit_fournisseur = reader.GetString(5);
                siretFournisseur = reader.GetString(6);
                nomEntreprise = reader.GetString(7);
                contact = reader.GetString(9);
                adresse = reader.GetString(10);
                libelle = reader.GetString(11);
                stock = 0;
                foreach (Piece p in pieces)
                {
                    if (p.Numero == numeroProduit)
                    {
                        stock = p.Stock;
                    }
                }
                Console.WriteLine("-------------------------------");
                Console.WriteLine(numeroProduit + "\n" + description + "\n" + date_intro + "\n" + date_discont_prod + "\n" + delai_approvisionnement + "\n" + numero_produit_fournisseur + "\n" + siretFournisseur + "\n" + nomEntreprise + "\n" + contact + "\n" + adresse + "\n" + libelle + '\n'+stock);
            }



            connection.Close();
        }

        static void parVelo(MySqlConnection connection)
        //Gestion des stocks vélo
        {
            connection.Open();

            MySqlCommand command = connection.CreateCommand();
            command.CommandText =
                "SELECT nomB, count(*) as Nombre "
                + "FROM Modele_Bicyclette m "
                + "GROUP BY m.nomB;";

            MySqlDataReader reader;
            reader = command.ExecuteReader();

            string nomB;
            int Nombre = 0;

            while (reader.Read())// parcours ligne par ligne
            {
                nomB = reader.GetString(0);  // récupération de la 1ère colonne (il n'y en a qu'une dans la requête !)
                Nombre = reader.GetInt32(1);
                Console.WriteLine(nomB + " : " + Nombre + " de modele différents");
            }

            connection.Close();

            connection.Open();

            Console.WriteLine("Pour quel vélo souhaitez-vous connaitre plus de détails ? (Kilimanjaro, NorthPole, MontBlanc, Hooligan, Orléans, BlueJay, Trail Explorer, Night Hawk, Tierra Verde, Mud Zinger I, Mud Zinger II )");
            string velo = Console.ReadLine();
            command = connection.CreateCommand();
            command.CommandText =
                "SELECT * "
                + "FROM Modele_Bicyclette m "
                + "WHERE m.nomB = '" + velo + "';";

            reader = command.ExecuteReader();
            List<Velo> velos = LectureStockVelo();
            int numModele;
            int prixUnitaire;
            string ligne_produit;
            string date_intro;
            string date_discont_prod;
            string grandeur;
            /*string cadre;
            string freins;
            string guidon;
            string selle;
            string derailleur_Avant;
            string derailleur_Arrière;
            string roue_Avant;
            string roue_Arrière;
            string reflecteurs;
            string pedalier;
            string ordinateur;
            string panier;*/
            int stock;
            int prix;
            while (reader.Read())// parcours ligne par ligne
            {
                numModele = reader.GetInt32(0);
                nomB = reader.GetString(1);
                prixUnitaire = reader.GetInt32(2);
                ligne_produit = reader.GetString(3);
                date_intro = reader.GetString(4);
                date_discont_prod = reader.GetString(5);
                grandeur = reader.GetString(6);
                stock = 0;
                prix = 0;
                //cadre = reader.GetString(7);
                //freins = reader.GetString(8);

                // Parfois guidon est null et dans ce case .GetString renvoie une erreur

                /*guidon = reader.GetString(9);
                selle = reader.GetString(10);
                derailleur_Avant = reader.GetString(11);
                derailleur_Arrière = reader.GetString(12);
                roue_Avant = reader.GetString(13);
                roue_Arrière = reader.GetString(14);
                reflecteurs = reader.GetString(15);
                pedalier = reader.GetString(16);
                ordinateur = reader.GetString(17);
                panier = reader.GetString(18);*/
                foreach(Velo v in velos)
                {
                    if(v.NumModel==numModele)
                    {
                        stock = v.Stock;
                        prix = v.Prix;
                    }
                }
                Console.WriteLine("-------------------------");
                Console.WriteLine(numModele + "\n" + nomB + "\n" + prixUnitaire + "\n" + ligne_produit + "\n" + date_intro + "\n" + date_discont_prod + "\n" + grandeur + "\n" + stock + "\n" + prix + " euros");
            }



            connection.Close();
        }


        static void parCategorieVelo(MySqlConnection connection)
        //Gestion des stocks par catégorie de vélo
        {
            connection.Open();

            MySqlCommand command = connection.CreateCommand();
            command.CommandText =
                "SELECT ligne_produit, count(*) as Nombre "
                + "FROM Modele_Bicyclette m "
                + "GROUP BY m.ligne_produit;";

            MySqlDataReader reader;
            reader = command.ExecuteReader();

            string ligne_produit;
            int Nombre = 0;

            while (reader.Read())// parcours ligne par ligne
            {
                ligne_produit = reader.GetString(0);  // récupération de la 1ère colonne (il n'y en a qu'une dans la requête !)
                Nombre = reader.GetInt32(1);
                Console.WriteLine(ligne_produit + " : " + Nombre);
            }

            connection.Close();

            connection.Open();

            Console.WriteLine("Pour quel catégorie de vélo souhaitez-vous connaitre plus de détails ? ( VTT, Vélo de course, Classique, BMX )");
            string categorie = Console.ReadLine();
            command = connection.CreateCommand();
            command.CommandText =
                "SELECT * "
                + "FROM Modele_Bicyclette m "
                + "WHERE m.ligne_produit = '" + categorie + "';";

            reader = command.ExecuteReader();

            int numModele;
            int prixUnitaire;
            string nomB;
            string date_intro;
            string date_discont_prod;
            string grandeur;
            /*string cadre;
            string freins;
            string guidon;
            string selle;
            string derailleur_Avant;
            string derailleur_Arrière;
            string roue_Avant;
            string roue_Arrière;
            string reflecteurs;
            string pedalier;
            string ordinateur;
            string panier;*/
            List<Velo> velos = new List<Velo>();
            int stock;
            int prix;
            while (reader.Read())// parcours ligne par ligne
            {
                numModele = reader.GetInt32(0);
                nomB = reader.GetString(1);
                prixUnitaire = reader.GetInt32(2);
                ligne_produit = reader.GetString(3);
                date_intro = reader.GetString(4);
                date_discont_prod = reader.GetString(5);
                grandeur = reader.GetString(6);
                //cadre = reader.GetString(7);
                //freins = reader.GetString(8);

                // Parfois guidon est null et dans ce case .GetString renvoie une erreur

                /*guidon = reader.GetString(9);
                selle = reader.GetString(10);
                derailleur_Avant = reader.GetString(11);
                derailleur_Arrière = reader.GetString(12);
                roue_Avant = reader.GetString(13);
                roue_Arrière = reader.GetString(14);
                reflecteurs = reader.GetString(15);
                pedalier = reader.GetString(16);
                ordinateur = reader.GetString(17);
                panier = reader.GetString(18);*/
                stock = 0;
                prix = 0;
                foreach (Velo v in velos)
                {
                    if (v.NumModel == numModele)
                    {
                        stock = v.Stock;
                        prix = v.Prix;
                    }
                }
                Console.WriteLine("-------------------------");
                Console.WriteLine(numModele + "\n" + nomB + "\n" + prixUnitaire + "\n" + ligne_produit + "\n" + date_intro + "\n" + date_discont_prod + "\n" + grandeur+"\n"+stock+"\n"+prix+" euros");

            }



            connection.Close();
        }



        static void parGrandeur(MySqlConnection connection)
        //Gestion des stocks par grandeur
        {
            connection.Open();

            MySqlCommand command = connection.CreateCommand();
            command.CommandText =
                "SELECT grandeur, count(*) as Nombre "
                + "FROM Modele_Bicyclette m "
                + "GROUP BY m.grandeur;";

            MySqlDataReader reader;
            reader = command.ExecuteReader();

            string grandeur;
            int Nombre = 0;

            while (reader.Read())// parcours ligne par ligne
            {
                grandeur = reader.GetString(0);  // récupération de la 1ère colonne (il n'y en a qu'une dans la requête !)
                Nombre = reader.GetInt32(1);
                Console.WriteLine(grandeur + " : " + Nombre);
            }

            connection.Close();

            connection.Open();

            Console.WriteLine("Pour quel type de vélo souhaitez-vous connaitre plus de détails ? ( Adultes, Jeunes, Hommes, Dames, Filles, Garçons )");
            string type = Console.ReadLine();
            command = connection.CreateCommand();
            command.CommandText =
                "SELECT * "
                + "FROM Modele_Bicyclette m "
                + "WHERE m.grandeur = '" + type + "';";

            reader = command.ExecuteReader();
            List<Velo> velos = new List<Velo>();
            int numModele;
            int prixUnitaire;
            string nomB;
            string date_intro;
            string date_discont_prod;
            string ligne_produit;
            /*string cadre;
            string freins;
            string guidon;
            string selle;
            string derailleur_Avant;
            string derailleur_Arrière;
            string roue_Avant;
            string roue_Arrière;
            string reflecteurs;
            string pedalier;
            string ordinateur;
            string panier;*/
            int stock;
            int prix;
            while (reader.Read())// parcours ligne par ligne
            {
                numModele = reader.GetInt32(0);
                nomB = reader.GetString(1);
                prixUnitaire = reader.GetInt32(2);
                ligne_produit = reader.GetString(3);
                date_intro = reader.GetString(4);
                date_discont_prod = reader.GetString(5);
                grandeur = reader.GetString(6);
                //cadre = reader.GetString(7);
                //freins = reader.GetString(8);

                // Parfois guidon est null et dans ce case .GetString renvoie une erreur

                /*guidon = reader.GetString(9);
                selle = reader.GetString(10);
                derailleur_Avant = reader.GetString(11);
                derailleur_Arrière = reader.GetString(12);
                roue_Avant = reader.GetString(13);
                roue_Arrière = reader.GetString(14);
                reflecteurs = reader.GetString(15);
                pedalier = reader.GetString(16);
                ordinateur = reader.GetString(17);
                panier = reader.GetString(18);*/
                stock = 0;
                prix = 0;
                foreach (Velo v in velos)
                {
                    if (v.NumModel == numModele)
                    {
                        stock = v.Stock;
                        prix = v.Prix;
                    }
                }
                Console.WriteLine("-------------------------");
                Console.WriteLine(numModele + "\n" + nomB + "\n" + prixUnitaire + "\n" + ligne_produit + "\n" + date_intro + "\n" + date_discont_prod + "\n" + grandeur+"\n"+prix+" euros");

            }



            connection.Close();
        }

        static void parPrixUnitaire(MySqlConnection connection)
        //Gestion des stocks par prix unitaire
        {
            connection.Open();

            MySqlCommand command = connection.CreateCommand();
            command.CommandText =
                "SELECT prixUnitaire, count(*) as Nombre "
                + "FROM Modele_Bicyclette m "
                + "GROUP BY m.prixUnitaire;";

            MySqlDataReader reader;
            reader = command.ExecuteReader();

            int prixUnitaire;
            int Nombre = 0;

            while (reader.Read())// parcours ligne par ligne
            {
                prixUnitaire = reader.GetInt32(0);  // récupération de la 1ère colonne (il n'y en a qu'une dans la requête !)
                Nombre = reader.GetInt32(1);
                Console.WriteLine(prixUnitaire + " : " + Nombre);
            }

            connection.Close();

            connection.Open();

            Console.WriteLine("Pour quel prix maximal de vélo souhaitez-vous connaitre plus de détails ? (en euros)");
            int prix = Convert.ToInt32(Console.ReadLine());
            command = connection.CreateCommand();
            command.CommandText =
                "SELECT * "
                + "FROM Modele_Bicyclette m "
                + "WHERE m.prixUnitaire <= " + prix + ";";

            reader = command.ExecuteReader();
            List<Velo> velos = new List<Velo>();
            int numModele;
            string grandeur;
            string nomB;
            string date_intro;
            string date_discont_prod;
            string ligne_produit;
            /*string cadre;
            string freins;
            string guidon;
            string selle;
            string derailleur_Avant;
            string derailleur_Arrière;
            string roue_Avant;
            string roue_Arrière;
            string reflecteurs;
            string pedalier;
            string ordinateur;
            string panier;*/
            int stock;
            
            while (reader.Read())// parcours ligne par ligne
            {
                numModele = reader.GetInt32(0);
                nomB = reader.GetString(1);
                prixUnitaire = reader.GetInt32(2);
                ligne_produit = reader.GetString(3);
                date_intro = reader.GetString(4);
                date_discont_prod = reader.GetString(5);
                grandeur = reader.GetString(6);
                //cadre = reader.GetString(7);
                //freins = reader.GetString(8);

                // Parfois guidon est null et dans ce case .GetString renvoie une erreur

                /*guidon = reader.GetString(9);
                selle = reader.GetString(10);
                derailleur_Avant = reader.GetString(11);
                derailleur_Arrière = reader.GetString(12);
                roue_Avant = reader.GetString(13);
                roue_Arrière = reader.GetString(14);
                reflecteurs = reader.GetString(15);
                pedalier = reader.GetString(16);
                ordinateur = reader.GetString(17);
                panier = reader.GetString(18);*/
                stock = 0;
                prix = 0;
                foreach (Velo v in velos)
                {
                    if (v.NumModel == numModele)
                    {
                        stock = v.Stock;
                        prix = v.Prix;
                    }
                }
                Console.WriteLine("-------------------------");
                Console.WriteLine(numModele + "\n" + nomB + "\n" + prixUnitaire + "\n" + ligne_produit + "\n" + date_intro + "\n" + date_discont_prod + "\n" + grandeur+"\n"+stock+"\n"+prix+" euros");

            }



            connection.Close();
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        static void ListeMembrePourChaqueProgramme(MySqlConnection connection)
        //Module statistique
        {
            connection.Open();

            MySqlCommand command = connection.CreateCommand();
            MySqlDataReader reader;

            Console.WriteLine("Pour quel programme d'admission souhaitez-vous connaitre les membres ? (1,2,3,4)");
            int num = Convert.ToInt32(Console.ReadLine());
            command = connection.CreateCommand();
            command.CommandText =
                "SELECT numSecu, prenom "
                + "FROM Particulier p "
                + "WHERE p.noProgramme = " + num + ";";

            reader = command.ExecuteReader();

            string numSecu;
            string prenom;

            while (reader.Read())// parcours ligne par ligne
            {
                // prix = Convert.ToInt32(Console.ReadLine());
                numSecu = reader.GetString(0);
                prenom = reader.GetString(1);

                //Console.WriteLine(marque);
                Console.WriteLine("Numéro de sécurité sociale : " + numSecu);
                Console.WriteLine("Prénom : " + prenom);

            }



            connection.Close();
        }

        static void NombreClient(MySqlConnection connection)
        {
            connection.Open();

            MySqlCommand command = connection.CreateCommand();
            MySqlDataReader reader;

            command = connection.CreateCommand();
            command.CommandText =
                "SELECT count(*) "
                + "FROM Client c;";

            reader = command.ExecuteReader();

            int nbClient = 0;

            while (reader.Read())// parcours ligne par ligne
            {
                nbClient = reader.GetInt32(0);
                Console.WriteLine("Vous avez " + nbClient + " clients");
            }



            connection.Close();
        }

        static void CreationFournisseur(MySqlConnection connection)
        {
            connection.Open();

            MySqlCommand command = connection.CreateCommand();
           
            
            Console.WriteLine("Saisir le nom");
            string nom = Console.ReadLine();
            Console.WriteLine("Saisir le siret");
            string siret = Console.ReadLine();
            Console.WriteLine("Saisir le numéro de téléphone");
            string tel = Console.ReadLine();
            Console.WriteLine("Saisir l'adresse");
            string adresse = Console.ReadLine();
            Console.WriteLine("Saisir le libelle (1,2,3,4)");
            int libelle = Convert.ToInt32(Console.ReadLine());

            
            command.CommandText = "INSERT INTO Fournisseur VALUE(@Nom,@Siret,@tel,@adresse,@libelle);";
            command.Parameters.Add(new MySqlParameter("@Nom", nom));
            command.Parameters.Add(new MySqlParameter("@Siret", siret));
            command.Parameters.Add(new MySqlParameter("@tel", tel));
            command.Parameters.Add(new MySqlParameter("@adresse", adresse));
            command.Parameters.Add(new MySqlParameter("@libelle", libelle));
            command.ExecuteNonQuery();
            connection.Close();
        }

        static void AffichageFournisseur(MySqlConnection connection)
        {
           connection.Open();
            MySqlCommand command = connection.CreateCommand();
            MySqlDataReader reader;

            command = connection.CreateCommand();
            command.CommandText =
                "SELECT * FROM Fournisseur;";
            reader = command.ExecuteReader();
            while(reader.Read())
            {
                Console.WriteLine("---------------------------------");
                Console.WriteLine("Nom :" + reader.GetString(0));
                Console.WriteLine("Siret :" + reader.GetString(1));
                Console.WriteLine("Numéro de téléphone :" + reader.GetString(2));
                Console.WriteLine("Adresse :" + reader.GetString(3));
                Console.WriteLine("Libelle :" + reader.GetInt32(4));
                Console.WriteLine("---------------------------------");
            }
            connection.Close();
        }

        static void MiseAJourFournisseur(MySqlConnection connection)
        {
            
            MySqlCommand command = connection.CreateCommand();
            
            command = connection.CreateCommand();
            Console.WriteLine("Liste des Fournisseurs");
            Console.WriteLine("");
            AffichageFournisseur(connection);
            Console.WriteLine("Saisir le siret du fournisseur à mettre à jour");
            string siret = Console.ReadLine();
            Console.Clear();
            Console.WriteLine("Saisir 1 pour actualiser le nom");
            Console.WriteLine("Saisir 2 pour actualiser l'adresse");
            Console.WriteLine("Saisir 3 pour actualiser le numero de téléphone");
            Console.WriteLine("Saisir 4 pour actualiser le libelle");
            int nb = Convert.ToInt32(Console.ReadLine());
            switch (nb)
            {
                case 1:
                    connection.Open();
                    command.CommandText = "UPDATE Fournisseur set nomEntreprise = @nom where siretFournisseur=@siret";
                    Console.WriteLine("Saisir le nouveau nom");
                    string nom = Console.ReadLine();
                    command.Parameters.Add(new MySqlParameter("@siret", siret));
                    command.Parameters.Add(new MySqlParameter("@nom", nom));
                    command.ExecuteNonQuery();
                    
                    break;
                case 2:
                    connection.Open();
                    command.CommandText = "UPDATE Fournisseur set adresse = @adresse where siretFournisseur=@siret";
                    Console.WriteLine("Saisir la nouvelle adresse");
                    string adresse = Console.ReadLine();
                    command.Parameters.Add(new MySqlParameter("@siret", siret));
                    command.Parameters.Add(new MySqlParameter("@adresse", adresse));
                    command.ExecuteNonQuery();
                    break;
                case 3:
                    connection.Open();
                    command.CommandText = "UPDATE Fournisseur set contact = @contact where siretFournisseur=@siret";
                    Console.WriteLine("Saisir le nouveau numéro de téléphone");
                    string contact = Console.ReadLine();
                    command.Parameters.Add(new MySqlParameter("@siret", siret));
                    command.Parameters.Add(new MySqlParameter("@contact", contact));
                    command.ExecuteNonQuery();
                    break;
                case 4:
                    connection.Open();
                    command.CommandText = "UPDATE Fournisseur set libelle = @libelle where siretFournisseur=@siret";
                    Console.WriteLine("Saisir le nouveau libelle");
                    int libelle = Convert.ToInt32(Console.ReadLine());
                    command.Parameters.Add(new MySqlParameter("@siret", siret));
                    command.Parameters.Add(new MySqlParameter("@libelle", libelle));
                    command.ExecuteNonQuery();
                    break;

                default:
                    { Console.WriteLine("Choix indisponible"); break; }
            }
            connection.Close();
        }

        static void SuppressionFournisseur(MySqlConnection connection)
        {
            
            MySqlCommand command1 = connection.CreateCommand();
            MySqlCommand command2 = connection.CreateCommand();
            command1 = connection.CreateCommand();
            command2 = connection.CreateCommand();
            Console.WriteLine("Liste des Fournisseurs");
            Console.WriteLine("");
            AffichageFournisseur(connection);
            Console.WriteLine("Saisir le siret du fournisseur à supprimer");
            string siret = Console.ReadLine();
            connection.Open();
            command1.CommandText = "DELETE FROM Fournisseur where siretFournisseur=@siret";
            command1.Parameters.Add(new MySqlParameter("@siret", siret));
            command2.CommandText = "DELETE FROM Piece_rechange p where p.siretFournisseur=@siret";
            command2.Parameters.Add(new MySqlParameter("@siret", siret));
            command2.ExecuteNonQuery();
            command1.ExecuteNonQuery();            
            connection.Close();
        }

        static void CreationPiece(MySqlConnection connection)
        {
            AffichageFournisseur(connection);
            connection.Open();
            MySqlCommand command = connection.CreateCommand();
            Console.WriteLine("Saisir le numero de produit");
            string num = Console.ReadLine();
            Console.WriteLine("Saisir la description");
            string description = Console.ReadLine();
            Console.WriteLine("Saisir la date d'introduction");
            string dateintro = Console.ReadLine();
            Console.WriteLine("Saisir la date de discontinuation");
            string datedisc = Console.ReadLine();
            Console.WriteLine("Saisir le delai d'aprovisionnement");
            int delai = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Saisir le numéro produit au catalogue du fournisseur");
            string numProdF = Console.ReadLine();
            Console.WriteLine("Saisir le siret du fournisseur");
            string siret = Console.ReadLine();
            command.CommandText = "INSERT INTO Piece_rechange VALUE(@numeroProduit,@description,@date_intro,@date_discont_prod,@delai_approvisionnement,@numero_produit_fournisseur,@siretFournisseur);";
            command.Parameters.Add(new MySqlParameter("@numeroProduit", num));
            command.Parameters.Add(new MySqlParameter("@description", description));
            command.Parameters.Add(new MySqlParameter("@date_intro", dateintro));
            command.Parameters.Add(new MySqlParameter("@date_discont_prod", datedisc));
            command.Parameters.Add(new MySqlParameter("@delai_approvisionnement", delai));
            command.Parameters.Add(new MySqlParameter("@numero_produit_fournisseur", numProdF));
            command.Parameters.Add(new MySqlParameter("@siretFournisseur", siret));
            command.ExecuteNonQuery();
            connection.Close();
        }

        static void AffichagePiece(MySqlConnection connection)
        {
            connection.Open();
            MySqlCommand command = connection.CreateCommand();
            MySqlDataReader reader;

            command = connection.CreateCommand();
            command.CommandText =
                "SELECT * FROM Piece_rechange;";
            reader = command.ExecuteReader();
            while (reader.Read())
            {
                Console.WriteLine("---------------------------------");
                Console.WriteLine("numero du produit :" + reader.GetString(0));
                Console.WriteLine("description :" + reader.GetString(1));
                Console.WriteLine("date d'introduction :" + reader.GetString(2));
                Console.WriteLine("date de discontinuation de production :" + reader.GetString(3));
                Console.WriteLine("Délai d'aprovisionnement :" + reader.GetInt32(4));
                Console.WriteLine("Numero du produit chez le fournisseur :" + reader.GetString(5));
                Console.WriteLine("Siret du fournisseur :" + reader.GetString(6));
                Console.WriteLine("---------------------------------");
            }
            connection.Close();
        }

        static void SuppressionPiece(MySqlConnection connection)
        {
            List < Piece > pieces= LectureStock();
            Console.WriteLine("Liste des pieces");
            Console.WriteLine("");
            AffichagePiece(connection);
            connection.Open();
            Console.WriteLine("Saisir le numéro de la pièce à suprimer");
            string num = Console.ReadLine();
            MySqlCommand command1 = connection.CreateCommand();
            command1.CommandText = "DELETE FROM Piece_rechange p where p.numeroProduit=@numeroProduit";
            command1.Parameters.Add(new MySqlParameter("@numeroProduit", num));
            command1.ExecuteNonQuery();
            connection.Close();
            foreach(Piece p in pieces)
            {
                if(p.Numero==num)
                {
                    pieces.Remove(p);
                }
            }
            SauvegardeStock(pieces);
        }

        static void ModificationPiece(MySqlConnection connection)
        {
            MySqlCommand command = connection.CreateCommand();

            command = connection.CreateCommand();
            Console.WriteLine("Liste des produits");
            Console.WriteLine("");
            AffichageFournisseur(connection);
            Console.WriteLine("Saisir le numéro du produit à mettre à jour");
            string num = Console.ReadLine();
            Console.Clear();
            Console.WriteLine("Saisir 1 pour actualiser le délai d'aprovisionnement");
            Console.WriteLine("Saisir 2 pour actualiser le numéro de produit chez le fournisseur");
            Console.WriteLine("Saisir 3 pour actualiser le siret du fournisseur");
            
            int nb = Convert.ToInt32(Console.ReadLine());
            switch(nb)
            {
                case 1:
                    Console.WriteLine("Saisir le nouveau délai");
                    int delai = Convert.ToInt32(Console.ReadLine());
                    connection.Open();
                    command.CommandText = "UPDATE Piece_rechange set delai_approvisionnement = @delai where numeroProduit=@num";
                    command.Parameters.Add(new MySqlParameter("@delai", delai));
                    command.Parameters.Add(new MySqlParameter("@num", num));
                    command.ExecuteNonQuery();                    
                    break;
                case 2:
                    Console.WriteLine("Saisir le nouveau numéro de produit chez le fournisseur");
                    string numF = Console.ReadLine();
                    connection.Open();
                    command.CommandText = "UPDATE Piece_rechange set numero_produit_fournisseur = @numF where numeroProduit=@num";
                    command.Parameters.Add(new MySqlParameter("@numF", numF));
                    command.Parameters.Add(new MySqlParameter("@num", num));
                    command.ExecuteNonQuery();
                    break;
                case 3:
                    Console.WriteLine("Saisir le siret du nouveau fournisseur");
                    string siret = Console.ReadLine();
                    connection.Open();
                    command.CommandText = "UPDATE Piece_rechange set siretFournisseur = @siret where numeroProduit=@num";
                    command.Parameters.Add(new MySqlParameter("@siret", siret));
                    command.Parameters.Add(new MySqlParameter("@num", num));
                    command.ExecuteNonQuery();
                    break;
                default:
                    { Console.WriteLine("Choix indisponible"); break; }
            }
            connection.Close();
        }

        static void AffichageVelos(MySqlConnection connection)
        {
            connection.Open();
            MySqlCommand command = connection.CreateCommand();
            MySqlDataReader reader;

            command = connection.CreateCommand();
            command.CommandText =
                "SELECT * FROM Modele_Bicyclette;";
            reader = command.ExecuteReader();
            while (reader.Read())
            {
                Console.WriteLine("---------------------------------");
                Console.WriteLine("Numero du modèle :" + reader.GetInt32(0));
                Console.WriteLine("Nom :" + reader.GetString(1));
                Console.WriteLine("Ligne produit :" + reader.GetString(3));
                Console.WriteLine("Date d'introduction :" + reader.GetString(4));
                Console.WriteLine("Date de discontinuation de production :" + reader.GetString(5));
                Console.WriteLine("Grandeur:" + reader.GetString(6));
                Console.WriteLine("Prix :" + reader.GetInt32(2)+" euros");
                Console.WriteLine("---------------------------------");
            }
            connection.Close();
        }

        static void CreerVelo(MySqlConnection connection)
        {
            Console.WriteLine("Pour chaque composant du vélo si celui-ci est abscent écrire : null");
            Console.WriteLine();
            Console.WriteLine("Saisir le numéro du vélo");
            int num = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Saisir le nom du vélo");
            string nom = Console.ReadLine();
            Console.WriteLine("Saisir le prix");
            int prix = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Saisir la ligne du produit");
            string ligne = Console.ReadLine();
            Console.WriteLine("Saisir le date d'introduction");
            string dateintro = Console.ReadLine();
            Console.WriteLine("Saisir la date de discontinuation de production");
            string datedisc = Console.ReadLine();
            Console.WriteLine("Saisir la grandeur");
            string grandeur = Console.ReadLine();
            Console.WriteLine("Saisir le cadre");
            string cadre = Console.ReadLine();
            Console.WriteLine("Saisir le guidon");
            string guidon = Console.ReadLine();
            Console.WriteLine("Saisir les freins");
            string freins = Console.ReadLine();
            Console.WriteLine("Saisir la selle");
            string selle = Console.ReadLine();
            Console.WriteLine("Saisir le déralleur avant");
            string dav = Console.ReadLine();
            Console.WriteLine("Saisir le dérailleur arrière");
            string dar = Console.ReadLine();
            Console.WriteLine("Saisir la roue avant");
            string rav = Console.ReadLine();
            Console.WriteLine("Saisir la roue arrière");
            string rar = Console.ReadLine();
            Console.WriteLine("Saisir le reflecteur");
            string refl = Console.ReadLine();
            Console.WriteLine("Saisir le pédalier");
            string ped = Console.ReadLine();
            Console.WriteLine("Saisir l'ordinateur");
            string ordi = Console.ReadLine();
            Console.WriteLine("Saisir le panier");
            string pan = Console.ReadLine();
            connection.Open();
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = "INSERT INTO Modele_Bicyclette VALUES(@num,@nom,@prix,@ligne,@dateintro,@datedisc,@datedisc,@grandeur,@cadre,@guidon,@freins,@selle,@dav,@dar,@rav,@rar,@refl,@ordi,@pan);";
            command.Parameters.Add(new MySqlParameter("@num", num));
            command.Parameters.Add(new MySqlParameter("@nom", nom));
            command.Parameters.Add(new MySqlParameter("@prix", prix));
            command.Parameters.Add(new MySqlParameter("@ligne", ligne));
            command.Parameters.Add(new MySqlParameter("@dateintro", dateintro));
            command.Parameters.Add(new MySqlParameter("@datedisc", datedisc));
            command.Parameters.Add(new MySqlParameter("@grandeur", grandeur));
            command.Parameters.Add(new MySqlParameter("@cadre", cadre));
            command.Parameters.Add(new MySqlParameter("@guidon", guidon));
            command.Parameters.Add(new MySqlParameter("@freins", freins));
            command.Parameters.Add(new MySqlParameter("@selle", selle));
            command.Parameters.Add(new MySqlParameter("@dav", dav));
            command.Parameters.Add(new MySqlParameter("@dar", dar));
            command.Parameters.Add(new MySqlParameter("@rav", rar));
            command.Parameters.Add(new MySqlParameter("@refl", refl));
            command.Parameters.Add(new MySqlParameter("@ordi", ordi));
            command.Parameters.Add(new MySqlParameter("@pan", pan));
            command.ExecuteNonQuery();
            connection.Close();
        }

        static void ModificationVelo(MySqlConnection connection)
        {
            Console.WriteLine("Liste des vélos");
            Console.WriteLine("");
            AffichageVelos(connection);
            connection.Open();
            Console.WriteLine("Saisir le numéro du vélo à modifier");
            int num = Convert.ToInt32(Console.ReadLine());
            Console.Clear();
            Console.WriteLine("Saisir 1 pour modifier le nom du vélo");
            Console.WriteLine("Saisir 2 pour modifier le prix");
            Console.WriteLine("Saisir 3 pour modifier la ligne");
            Console.WriteLine("Saisir 4 pour modifier la date d'intoduction");
            Console.WriteLine("Saisir 5 pour modifier la date de discontinuation de production");
            Console.WriteLine("Saisir 6 pour modifier la grandeur");
            Console.WriteLine("Saisir 7 pour modifier le cadre");
            Console.WriteLine("Saisir 8 pour modifier le guidon");
            Console.WriteLine("Saisir 9 pour modifier les freins");
            Console.WriteLine("Saisir 10 pour modifier la selle");
            Console.WriteLine("Saisir 11 pour modifier le dérailleur avant");
            Console.WriteLine("Saisir 12 pour modifier le derailleur arrière");
            Console.WriteLine("Saisir 13 pour modifier la roue avant");
            Console.WriteLine("Saisir 14 pour modifier la roue arrière");
            Console.WriteLine("Saisir 15 pour modifier le reflecteur");
            Console.WriteLine("Saisir 16 pour modifier le pédalier");
            Console.WriteLine("Saisir 17 pour modifier l'ordinateur");
            Console.WriteLine("Saisir 18 pour modifier le panier");
            int nb = Convert.ToInt32(Console.ReadLine());
            MySqlCommand command = connection.CreateCommand();

            switch (nb)
            {
                case 1:
                    Console.WriteLine("Saisir le nouveau nom");
                    string nom = Console.ReadLine();
                    connection.Open();
                    command.CommandText = "UPDATE Modele_Bicyclette set nomB = @nom where numModele=@num";
                    command.Parameters.Add(new MySqlParameter("@nom", nom));
                    command.Parameters.Add(new MySqlParameter("@num", num));
                    command.ExecuteNonQuery();
                    break;
                case 2:
                    Console.WriteLine("Saisir le nouveau prix");
                    int prix = Convert.ToInt32(Console.ReadLine());
                    connection.Open();
                    command.CommandText = "UPDATE Modele_Bicyclette set prixUnitaire = @prix where numModele=@num";
                    command.Parameters.Add(new MySqlParameter("@prix", prix));
                    command.Parameters.Add(new MySqlParameter("@num", num));
                    command.ExecuteNonQuery();
                    break;
                case 3:
                    Console.WriteLine("Saisir la nouvelle ligne");
                    string ligne = Console.ReadLine();
                    connection.Open();
                    command.CommandText = "UPDATE Modele_Bicyclette set ligne_produit = @ligne where numModele=@num";
                    command.Parameters.Add(new MySqlParameter("@ligne", ligne));
                    command.Parameters.Add(new MySqlParameter("@num", num));
                    command.ExecuteNonQuery();
                    break;
                case 4:
                    Console.WriteLine("Saisir la nouvelle date d'introduction");
                    string dateintro = Console.ReadLine();
                    connection.Open();
                    command.CommandText = "UPDATE Modele_Bicyclette set date_intro = @dateintro where numModele=@num";
                    command.Parameters.Add(new MySqlParameter("@dateintro", dateintro));
                    command.Parameters.Add(new MySqlParameter("@num", num));
                    command.ExecuteNonQuery();
                    break;
                case 5:
                    Console.WriteLine("Saisir la nouvelle date de discontinuation de production");
                    string date_discont_prod = Console.ReadLine();
                    connection.Open();
                    command.CommandText = "UPDATE Modele_Bicyclette set date_discont_prod = @date_discont_prod where numModele=@num";
                    command.Parameters.Add(new MySqlParameter("@date_discont_prod", date_discont_prod));
                    command.Parameters.Add(new MySqlParameter("@num", num));
                    command.ExecuteNonQuery();
                    break;
                case 6:
                    Console.WriteLine("Saisir la nouvelle grandeur");
                    string grandeur = Console.ReadLine();
                    connection.Open();
                    command.CommandText = "UPDATE Modele_Bicyclette set grandeur = @grandeur where numModele=@num";
                    command.Parameters.Add(new MySqlParameter("@grandeur", grandeur));
                    command.Parameters.Add(new MySqlParameter("@num", num));
                    command.ExecuteNonQuery();
                    break;
                case 7:
                    Console.WriteLine("Saisir le nouveau cadre");
                    string cadre = Console.ReadLine();
                    connection.Open();
                    command.CommandText = "UPDATE Modele_Bicyclette set cadre = @cadre where numModele=@num";
                    command.Parameters.Add(new MySqlParameter("@cadre", cadre));
                    command.Parameters.Add(new MySqlParameter("@num", num));
                    command.ExecuteNonQuery();
                    break;
                case 8:
                    Console.WriteLine("Saisir le nouveau guidon");
                    string guidon = Console.ReadLine();
                    connection.Open();
                    command.CommandText = "UPDATE Modele_Bicyclette set guidon = @guidon where numModele=@num";
                    command.Parameters.Add(new MySqlParameter("@guidon", guidon));
                    command.Parameters.Add(new MySqlParameter("@num", num));
                    command.ExecuteNonQuery();
                    break;
                case 9:
                    Console.WriteLine("Saisir les nouveaux freins");
                    string freins = Console.ReadLine();
                    connection.Open();
                    command.CommandText = "UPDATE Modele_Bicyclette set freins = @freins where numModele=@num";
                    command.Parameters.Add(new MySqlParameter("@freins", freins));
                    command.Parameters.Add(new MySqlParameter("@num", num));
                    command.ExecuteNonQuery();
                    break;
                case 10:
                    Console.WriteLine("Saisir la nouvelle selle");
                    string selle = Console.ReadLine();
                    connection.Open();
                    command.CommandText = "UPDATE Modele_Bicyclette set selle = @selle where numModele=@num";
                    command.Parameters.Add(new MySqlParameter("@selle", selle));
                    command.Parameters.Add(new MySqlParameter("@num", num));
                    command.ExecuteNonQuery();
                    break;
                case 11:
                    Console.WriteLine("Saisir le nouveau derailleur avant");
                    string derailleur_Avant = Console.ReadLine();
                    connection.Open();
                    command.CommandText = "UPDATE Modele_Bicyclette set derailleur_Avant = @derailleur_Avant where numModele=@num";
                    command.Parameters.Add(new MySqlParameter("@derailleur_Avant", derailleur_Avant));
                    command.Parameters.Add(new MySqlParameter("@num", num));
                    command.ExecuteNonQuery();
                    break;
                case 12:
                    Console.WriteLine("Saisir le nouveau derailleur arrière");
                    string derailleur_Arrière = Console.ReadLine();
                    connection.Open();
                    command.CommandText = "UPDATE Modele_Bicyclette set derailleur_Arrière = @derailleur_Arrière where numModele=@num";
                    command.Parameters.Add(new MySqlParameter("@derailleur_Arrière", derailleur_Arrière));
                    command.Parameters.Add(new MySqlParameter("@num", num));
                    command.ExecuteNonQuery();
                    break;
                case 13:
                    Console.WriteLine("Saisir la nouvelle roue avant");
                    string roue_Avant = Console.ReadLine();
                    connection.Open();
                    command.CommandText = "UPDATE Modele_Bicyclette set roue_Avant = @roue_Avant where numModele=@num";
                    command.Parameters.Add(new MySqlParameter("@roue_Avant", roue_Avant));
                    command.Parameters.Add(new MySqlParameter("@num", num));
                    command.ExecuteNonQuery();
                    break;
                case 14:
                    Console.WriteLine("Saisir la nouvelle roue arrière");
                    string roue_Arrière = Console.ReadLine();
                    connection.Open();
                    command.CommandText = "UPDATE Modele_Bicyclette set roue_Arrière = @roue_Arrière where numModele=@num";
                    command.Parameters.Add(new MySqlParameter("@roue_Arrière", roue_Arrière));
                    command.Parameters.Add(new MySqlParameter("@num", num));
                    command.ExecuteNonQuery();
                    break;
                case 15:
                    Console.WriteLine("Saisir les nouveaux reflecteurs");
                    string reflecteurs = Console.ReadLine();
                    connection.Open();
                    command.CommandText = "UPDATE Modele_Bicyclette set reflecteurs = @reflecteurs where numModele=@num";
                    command.Parameters.Add(new MySqlParameter("@reflecteurs", reflecteurs));
                    command.Parameters.Add(new MySqlParameter("@num", num));
                    command.ExecuteNonQuery();
                    break;
                case 16:
                    Console.WriteLine("Saisir le nouveau pédalier");
                    string pedalier = Console.ReadLine();
                    connection.Open();
                    command.CommandText = "UPDATE Modele_Bicyclette set pedalier = @pedalier where numModele=@num";
                    command.Parameters.Add(new MySqlParameter("@pedalier", pedalier));
                    command.Parameters.Add(new MySqlParameter("@num", num));
                    command.ExecuteNonQuery();
                    break;
                case 17:
                    Console.WriteLine("Saisir le nouvel ordinateur");
                    string ordinateur = Console.ReadLine();
                    connection.Open();
                    command.CommandText = "UPDATE Modele_Bicyclette set ordinateur = @ordinateur where numModele=@num";
                    command.Parameters.Add(new MySqlParameter("@ordinateur", ordinateur));
                    command.Parameters.Add(new MySqlParameter("@num", num));
                    command.ExecuteNonQuery();
                    break;
                case 18:
                    Console.WriteLine("Saisir le nouveau panier");
                    string panier = Console.ReadLine();
                    connection.Open();
                    command.CommandText = "UPDATE Modele_Bicyclette set panier = @panier where numModele=@num";
                    command.Parameters.Add(new MySqlParameter("@panier", panier));
                    command.Parameters.Add(new MySqlParameter("@num", num));
                    command.ExecuteNonQuery();
                    break;
                default:
                    { Console.WriteLine("Choix indisponible"); break; }
            }
            connection.Close();
        }

        static void SuppressionVelo(MySqlConnection connection)
        {
            List<Velo> velos = new List<Velo>();
            Console.WriteLine("Liste des vélos");
            Console.WriteLine("");
            AffichageVelos(connection);
            connection.Open();
            Console.WriteLine("Saisir le numéro du vélo à suprimer");
            int numModele = Convert.ToInt32(Console.ReadLine());
            MySqlCommand command1 = connection.CreateCommand();
            MySqlCommand command2 = connection.CreateCommand();
            command1.CommandText = "DELETE FROM Modele_Bicyclette where numModele=@numModele";
            command1.Parameters.Add(new MySqlParameter("@numModele", numModele));
            command2.CommandText = "DELETE FROM Bicyclette where numModele=@numModele";
            command2.Parameters.Add(new MySqlParameter("@numModele", numModele));
            command2.ExecuteNonQuery();
            command1.ExecuteNonQuery();
            connection.Close();
            foreach (Velo v in velos)
            {
                if (v.NumModel == numModele)
                {
                    velos.Remove(v);
                }
            }
            SauvegardeStockVelo(velos);
        }

        static void SauvegardeStock(List<Piece> pieces)
        {
            
            StreamWriter ecriture = new StreamWriter("Stock.csv");
            int n = pieces.Count;
            foreach (Piece p in pieces)
            {
                string ligne = "";
                ligne += p.Numero + ";"+p.Stock+";"+p.Prix;
                ecriture.WriteLine(ligne);
            }
            ecriture.Close();
        }

        static List<Piece> LectureStock()
        {
            StreamReader lecteur = new StreamReader("Stock.csv");
            string ligne = "";
            List<Piece> res=new List<Piece>();
            while (lecteur.Peek() > 0)
            {
                ligne = lecteur.ReadLine();
                if (ligne != null)
                {
                    string[] tem = ligne.Split(';');
                    res.Add(new Piece(tem[0], Convert.ToInt32(tem[1]),Convert.ToInt32(tem[2])));
                }
            }
            lecteur.Close();
            
            return res;
        }

        static List<Velo> LectureStockVelo()
        {
            StreamReader lecteur = new StreamReader("StockVelo.csv");
            string ligne = "";
            List<Velo> res = new List<Velo>();
            while (lecteur.Peek() > 0)
            {
                ligne = lecteur.ReadLine();
                if (ligne != null)
                {
                    string[] tem = ligne.Split(';');
                    res.Add(new Velo(Convert.ToInt32(tem[0]), Convert.ToInt32(tem[1]), Convert.ToInt32(tem[2])));
                }
            }
            lecteur.Close();

            return res;
        }

        static void SauvegardeStockVelo(List<Velo> velos)
        {

            StreamWriter ecriture = new StreamWriter("StockVelo.csv");
            int n = velos.Count;
            foreach (Velo v in velos)
            {
                string ligne = "";
                ligne += v.NumModel + ";" + v.Stock+";"+v.Prix;
                ecriture.WriteLine(ligne);
            }
            ecriture.Close();
        }

        static void CreationClient(MySqlConnection connection)
        {
            Console.Clear();
            connection.Open();
            
            Console.WriteLine("Saisir 1 pour creer un client particulier");
            Console.WriteLine("Saisir 2 pour creer un client boutique specialisée");
            int n = Convert.ToInt32(Console.ReadLine());
            switch(n)
            {
                case 1:
                    MySqlCommand command = connection.CreateCommand();
                    MySqlCommand command2 = connection.CreateCommand();
                    Console.Clear();
                    Console.WriteLine("Saisir nom");
                    string nom = Console.ReadLine();
                    Console.WriteLine("Saisir prenom");
                    string prenom = Console.ReadLine();
                    Console.WriteLine("Saisir le numero de secu");
                    string secu = Console.ReadLine();
                    Console.WriteLine("Saisir le numero de programe (si aucun mettre 0)");
                    int prog = Convert.ToInt32(Console.ReadLine());                    
                    Console.WriteLine("Saisir la ville");
                    string ville = Console.ReadLine();
                    Console.WriteLine("Saisir la rue");
                    string rue = Console.ReadLine();
                    Console.WriteLine("Saisir le code postal");
                    int codepostal = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Saisir la province");
                    string province = Console.ReadLine();
                    Console.WriteLine("Saisir le mail");
                    string mail = Console.ReadLine();
                    Console.WriteLine("Saisir le numero de telephone");
                    string tel = Console.ReadLine();
                    command.CommandText = "INSERT INTO Particulier Values(@secu,@prenom,@prog);";
                    command.Parameters.Add(new MySqlParameter("@secu", secu));
                    command.Parameters.Add(new MySqlParameter("@prenom", prenom));
                    if (prog != 0) { command.Parameters.Add(new MySqlParameter("@prog", prog)); } else { command.Parameters.Add(new MySqlParameter("@prog", null)); }
                    command.ExecuteNonQuery();
                    command2.CommandText = "INSERT INTO Client values(@nom,@tel,@ville,@rue,@codepostal,@province,@mail,@secu,Null);";
                    command2.Parameters.Add(new MySqlParameter("@nom", nom));
                    command2.Parameters.Add(new MySqlParameter("@tel", tel));
                    command2.Parameters.Add(new MySqlParameter("@ville", ville));
                    command2.Parameters.Add(new MySqlParameter("@rue", rue));
                    command2.Parameters.Add(new MySqlParameter("@codepostal", codepostal));
                    command2.Parameters.Add(new MySqlParameter("@province", province));
                    command2.Parameters.Add(new MySqlParameter("@mail", mail));
                    command2.Parameters.Add(new MySqlParameter("@secu", secu));
                    command2.ExecuteNonQuery();
                    break;
                case 2:
                    MySqlCommand command3 = connection.CreateCommand();
                    MySqlCommand command4 = connection.CreateCommand();
                    Console.Clear();
                    Console.WriteLine("Saisir le nom de la boutique");
                    string nomb = Console.ReadLine();
                    Console.WriteLine("Saisir le siret de la boutique");
                    string siret = Console.ReadLine();
                    Console.WriteLine("Saisir le nom du contact");
                    string contact = Console.ReadLine();
                    Console.WriteLine("Saisir le pourcentage de remise");
                    int remise = Convert.ToInt32(Console.ReadLine());                                      
                    
                    Console.WriteLine("Saisir la ville");
                    ville = Console.ReadLine();
                    Console.WriteLine("Saisir la rue");
                    rue = Console.ReadLine();
                    Console.WriteLine("Saisir le code postal");
                    codepostal = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Saisir la province");
                    province = Console.ReadLine();
                    Console.WriteLine("Saisir le mail");
                    mail = Console.ReadLine();
                    Console.WriteLine("Saisir le numero de telephone");
                    tel = Console.ReadLine();
                    command3.CommandText = "INSERT INTO Boutique_Specialisee Values(@siret,@contact,@remise);";
                    command3.Parameters.Add(new MySqlParameter("@siret", siret));
                    command3.Parameters.Add(new MySqlParameter("@contact", contact));
                    command3.Parameters.Add(new MySqlParameter("@remise", remise));
                    command3.ExecuteNonQuery();
                    command4.CommandText= "INSERT INTO Client values(@nom,@tel,@ville,@rue,@codepostal,@province,@mail,Null,@siret);";
                    command4.Parameters.Add(new MySqlParameter("@nom", nomb));
                    command4.Parameters.Add(new MySqlParameter("@tel", tel));
                    command4.Parameters.Add(new MySqlParameter("@ville", ville));
                    command4.Parameters.Add(new MySqlParameter("@rue", rue));
                    command4.Parameters.Add(new MySqlParameter("@codepostal", codepostal));
                    command4.Parameters.Add(new MySqlParameter("@province", province));
                    command4.Parameters.Add(new MySqlParameter("@mail", mail));
                    command4.Parameters.Add(new MySqlParameter("@siret", siret));
                    command4.ExecuteNonQuery();
                    break;
                default:
                    { Console.WriteLine("Choix indisponible"); break; }
            }
            connection.Close();
        }

        static void AfficherClient(MySqlConnection connection)
        {
            connection.Open();
            MySqlCommand command = connection.CreateCommand();
            MySqlDataReader reader;

            command = connection.CreateCommand();
            command.CommandText =
                "SELECT * FROM Client;";
            reader = command.ExecuteReader();
            while (reader.Read())
            {
                Console.WriteLine("---------------------------------");
                Console.WriteLine("Nom :" + reader.GetInt32(0));
                Console.WriteLine("Numero de téléphone :" + reader.GetString(1));
                Console.WriteLine("Ville :" + reader.GetString(2));
                Console.WriteLine("Rue :" + reader.GetString(3));
                Console.WriteLine("Code Postal :" + reader.GetInt32(4));
                Console.WriteLine("Province:" + reader.GetString(6));
                Console.WriteLine("Mail :" + reader.GetInt32(2) + " euros");
                Console.WriteLine("---------------------------------");
            }
            connection.Close();
        }

        /*static void SuprimerClient(MySqlConnection connection)
        {
            AfficherClient(connection);
            connection.Open();
            Console.WriteLine("Saisir 1 pour suprimer une entreprise cliente");
            Console.WriteLine("Saisir 2 pour suprimer un client particulier");
            Console.WriteLine("Saisir le nom du client à supprimer");
            string nom = Console.ReadLine();
            MySqlCommand command = new MySqlCommand();
            command.CommandText=""
        }*/
    }
}//class Programm


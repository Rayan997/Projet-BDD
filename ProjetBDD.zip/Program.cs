﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetBDD
{
    using MySql.Data.MySqlClient;
    using System.IO;

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Bonjour !");
            Console.WriteLine("");
            Console.WriteLine("------------------------------");
            Console.WriteLine("Saisir identifiant :");
            string id = Console.ReadLine();
            Console.WriteLine("Saisir mot de passe :");
            string mdp = Console.ReadLine();
            //string connectionString = "SERVER=localhost;PORT=3306;DATABASE=velomax;UID="+id +";PASSWORD="+mdp+";SSLMODE=none;";
            string connectionString = "SERVER=localhost;PORT=3306;DATABASE=velomax;UID=" + "root" + ";PASSWORD=" + "CourbevoieESILV.2020" + ";SSLMODE=none;";
            MySqlConnection connection = new MySqlConnection(connectionString);

            int nombre;
            int nb;

            Console.WriteLine("Bienvenue !");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            bool test = true;
            while (test == true)
            {
                Console.WriteLine("Saisir 1 pour consulter la gestion du stock");
                Console.WriteLine("Saisir 2 pour avoir des informations générales sur Velomax");
                Console.WriteLine("Saisir 3 pour gérer les fournisseurs");
                Console.WriteLine("Saisir 4 pour gérer les pièces détachées");
                nombre = int.Parse(Console.ReadLine());
                switch (nombre)
                {
                    #region Cas 1 : Consulter la gestion du stock
                    case 1:
                        {
                            RuptureDeStock(connection);
                            Console.WriteLine("Saisir 1 pour avoir un aperçu des stocks par pièce");
                            Console.WriteLine("Saisir 2 pour avoir un aperçu des stocks par fournisseur");
                            Console.WriteLine("Saisir 3 pour avoir un aperçu des stocks par vélo");
                            Console.WriteLine("Saisir 4 pour avoir un aperçu des stocks par catégorie de vélo");
                            Console.WriteLine("Saisir 5 pour avoir un aperçu des stocks par grandeur");
                            Console.WriteLine("Saisir 6 pour avoir un aperçu des stocks par prix unitaire");
                            Console.WriteLine("Saisir un autre nombre pour revenir à l'accueil");
                            nb = int.Parse(Console.ReadLine());
                            switch (nb)
                            {
                                case 1:
                                    {
                                        parPiece(connection);
                                        break;
                                    }
                                case 2:
                                    {
                                        parFournisseur(connection);
                                        break;
                                    }
                                case 3:
                                    {
                                        parVelo(connection);
                                        break;
                                    }
                                case 4:
                                    {
                                        parCategorieVelo(connection);
                                        break;
                                    }
                                case 5:
                                    {
                                        parGrandeur(connection);
                                        break;
                                    }
                                case 6:
                                    {
                                        parPrixUnitaire(connection);
                                        break;
                                    }
                                default:
                                    { Console.WriteLine(""); break; }
                            }
                            break;
                        }
                    #endregion

                    #region Cas 2 : Information général sur Velomax
                    case 2:
                        {
                            Console.Clear();
                            Console.WriteLine("Nombre de client");
                            Console.WriteLine("=================");
                            NombreClient(connection);
                            Console.WriteLine("\nappuyez sur une touche pour continuer");
                            Console.ReadKey();

                            Console.Clear();
                            Console.WriteLine("\n\nListe des membres par programme d’adhésion");
                            Console.WriteLine("=================");
                            ListeMembrePourChaqueProgramme(connection);
                            Console.WriteLine("\nappuyez sur une touche pour continuer");
                            Console.ReadKey();

                            /*Console.Clear();
                            Console.WriteLine("\n\n1.3 Liste des véhicules par prix de journée décroissant");
                            Console.WriteLine("=================");
                            //Exo3(connection);
                            Console.WriteLine("\nappuyez sur une touche pour continuer");
                            Console.ReadKey();

                            Console.Clear();
                            Console.WriteLine("\n\n1.4 Valeur moyenne des prix de journée");
                            Console.WriteLine("=================");
                            //Exo4(connection);
                            Console.WriteLine("\nappuyez sur une touche pour continuer");
                            Console.ReadKey();

                            Console.Clear();
                            Console.WriteLine("\n\n1.6 deuxième prix de journée minimum");
                            Console.WriteLine("\n=================");
                            //Exo6(connection);
                            Console.WriteLine("appuyez sur une touche pour continuer");
                            Console.ReadKey();
                            Console.WriteLine("\n1.6 deuxième prix de journée minimum version 2");
                            Console.WriteLine("\n=================");


                            Console.Clear();
                            Console.WriteLine("\n\n1.7 prix de journée médian");
                            Console.WriteLine("\n=================");
                            //Exo7(connection);
                            Console.WriteLine("appuyez sur une touche pour finir\n");

                            Console.Clear();
                            Console.WriteLine("\n\n1.7 prix de journée médian");
                            Console.WriteLine("\n=================");
                            //Exo8(connection);
                            Console.WriteLine("appuyez sur une touche pour finir\n");
                            Console.ReadKey();*/
                            break;
                        }
                    #endregion

                    #region Cas 3 : Gestion fournisseur
                    case 3:
                        {
                            Console.Clear();
                            Console.WriteLine("Saisir 1 pour ajouter un fournisseur");
                            Console.WriteLine("Saisir 2 pour afficher les fournisseurs");
                            Console.WriteLine("Saisir 3 pour mettre à jour un fournisseur");
                            Console.WriteLine("Saisir 4 pour suprimer un fournisseur");
                            int nb2 = Convert.ToInt32(Console.ReadLine());
                            switch(nb2)
                            {
                                case 1:
                                    CreationFournisseur(connection);
                                    break;
                                case 2:
                                    AffichageFournisseur(connection);
                                    break;
                                case 3:
                                    MiseAJourFournisseur(connection);
                                    break;
                                case 4:
                                    SuppressionFournisseur(connection);
                                    break;
                                default:
                                    { Console.WriteLine("Choix indisponible"); break; }
                            }


                            break;
                        }
                    #endregion

                    #region Cas 4 : Gestion des Pièces détachés
                    case 4:
                        Console.Clear();
                        Console.WriteLine("Saisir 1 pour afficher les pièces détachées");
                        int nb3 = Convert.ToInt32(Console.ReadLine());
                        switch(nb3)
                        {
                            case 1:
                                AffichagePiece(connection);
                                break;
                            case 2:
                                SuppressionPiece(connection);
                                break;
                            case 3:
                                ModificationPiece(connection);
                                break;
                            default:
                                { Console.WriteLine("Choix indisponible"); break; }
                        }
                        break;
                    #endregion

                    
                    default:
                        { Console.WriteLine("Choix indisponible"); break; }
                }
                Console.WriteLine("Voulez-vous revenir à l'écran d'accueil? ( true ou false )");
                test = Convert.ToBoolean(Console.ReadLine());
                if (test)
                {
                    Console.Clear();
                }
            }

            /* //Pour tester les fonctions une a une
            Console.WriteLine("fin des opérations");

            Console.Clear();
            Console.WriteLine("1.1 Liste des marques");
            Console.WriteLine("=================");
            //Exo1(connection);
            Console.WriteLine("\nappuyez sur une touche pour continuer");
            Console.ReadKey();

            Console.Clear();
            Console.WriteLine("\n\n1.2 Liste des propriétaires avec véhicules");
            Console.WriteLine("=================");
            //RuptureDeStock(connection);
            Console.WriteLine("\nappuyez sur une touche pour continuer");
            Console.ReadKey();

            Console.Clear();
            Console.WriteLine("\n\n1.3 Liste des véhicules par prix de journée décroissant");
            Console.WriteLine("=================");
            //Exo3(connection);
            Console.WriteLine("\nappuyez sur une touche pour continuer");
            Console.ReadKey();

            Console.Clear();
            Console.WriteLine("\n\n1.4 Valeur moyenne des prix de journée");
            Console.WriteLine("=================");
            //Exo4(connection);
            Console.WriteLine("\nappuyez sur une touche pour continuer");
            Console.ReadKey();

            Console.Clear();
            Console.WriteLine("\n\n1.6 deuxième prix de journée minimum");
            Console.WriteLine("\n=================");
            //Exo6(connection);
            Console.WriteLine("appuyez sur une touche pour continuer");
            Console.ReadKey();
            Console.WriteLine("\n1.6 deuxième prix de journée minimum version 2");
            Console.WriteLine("\n=================");


            Console.Clear();
            Console.WriteLine("\n\n1.7 prix de journée médian");
            Console.WriteLine("\n=================");
            //Exo7(connection);
            Console.WriteLine("appuyez sur une touche pour finir\n");

            Console.Clear();
            Console.WriteLine("\n\n1.7 prix de journée médian");
            Console.WriteLine("\n=================");
            //Exo8(connection);
            Console.WriteLine("appuyez sur une touche pour finir\n");
            Console.ReadKey();

            Console.Clear();
            Console.WriteLine("\n\n1.7 prix de journée médian");
            Console.WriteLine("\n=================");
            Exo9(connection);
            Console.WriteLine("appuyez sur une touche pour finir\n");
            Console.ReadKey();*/

            Console.ReadKey();

        }//main

        static void Exo0()
        {
            //lire le fichier clients.csv
            Console.WriteLine("Lecture du fichier clients.csv");
            Console.WriteLine("----------------------------");
            string nomFichier = "clients.csv";
            Lire(nomFichier);
            Console.WriteLine("----------------------------");
            Console.WriteLine("Appuyez sur une touche pour continuer...\n");
            Console.ReadKey();
            //
            // ecrire dans le fichier csv
            // le client supplémentaire
            Console.WriteLine("Ecriture dans le fichier clients.csv");
            Console.WriteLine("----------------------------");
            string nom = "Jouvet";
            string prenom = "Louis";
            int age = 80;
            string numPermis = "55555";
            string adresse = "rue du vent";
            string ville = "Paris";
            string newClient = nom + ";"
                + prenom + ";"
                + Convert.ToString(age) + ";"
                + numPermis + ";"
                + adresse + ";"
                + ville;
            bool append = true;
            Ecrire(newClient, nomFichier, append);

            //relire le fichier clients.csv
            Console.WriteLine("Relecture du fichier clients.csv");
            Console.WriteLine("----------------------------");
            Lire(nomFichier);
            Console.WriteLine("----------------------------\n");

        }
        static void Ecrire(string ligne, string fichier, bool append)
        {
            StreamWriter ecrire = new StreamWriter(fichier, true);
            ecrire.WriteLine(ligne);
            ecrire.Close();
        }
        static void Lire(string fichier)
        {
            string ligne = "";
            char[] sep = new char[1] { '1' };
            string[] datas = new string[6];

            StreamReader lecteur = new StreamReader(fichier);
            while (lecteur.Peek() > 0)
            {
                ligne = lecteur.ReadLine();
                Console.WriteLine("ligne lu " + ligne);
                datas = ligne.Split(';');
                //datas = ligne.Split(sep);
            }
            lecteur.Close();
        }



        static void parPiece(MySqlConnection connection)
        //Gestion des stocks par pièce
        {
            connection.Open();

            MySqlCommand command = connection.CreateCommand();
            command.CommandText =
                "SELECT description , count(*) as Nombre "
                + "FROM Piece_rechange p "
                + "GROUP BY p.description;";
            //" SELECT DISTINCT(marque) FROM voiture ;";

            MySqlDataReader reader;
            reader = command.ExecuteReader();

            string description;
            int Nombre = 0;

            while (reader.Read())// parcours ligne par ligne
            {
                // prix = Convert.ToInt32(Console.ReadLine());
                description = reader.GetString(0);  // récupération de la 1ère colonne (il n'y en a qu'une dans la requête !)
                Nombre = reader.GetInt32(1);
                //Console.WriteLine(marque);
                Console.WriteLine(description + " : " + Nombre);
            }

            connection.Close();

            connection.Open();

            Console.WriteLine("Pour quel pièce souhaitez-vous connaitre plus de détails ? ( cadre, guidon, freins, selle, derailleur avant, derailleur arrière, roue arrière, reflecteurs, pedalier, ordinateur, panier)");
            string piece = Console.ReadLine();
            command = connection.CreateCommand();
            command.CommandText =
                "SELECT * "
                + "FROM Piece_rechange p "
                + "WHERE p.description = '" + piece + "';";

            reader = command.ExecuteReader();

            string numeroProduit;
            string date_intro;
            string date_discont_prod;
            int delai_approvisionnement;
            string numero_produit_fournisseur;
            string siretFournisseur;


            


            while (reader.Read())// parcours ligne par ligne
            {
                // prix = Convert.ToInt32(Console.ReadLine());
                numeroProduit = reader.GetString(0);
                description = reader.GetString(1);
                date_intro = reader.GetString(2);
                date_discont_prod = reader.GetString(3);
                delai_approvisionnement = reader.GetInt32(4);
                numero_produit_fournisseur = reader.GetString(5);
                siretFournisseur = reader.GetString(6);

                //Console.WriteLine(marque);
                Console.WriteLine(numeroProduit + " : " + description + " , " + date_intro + " , " + date_discont_prod + " , " + delai_approvisionnement + " , " + numero_produit_fournisseur + " , " + siretFournisseur);
            }



            connection.Close();
        }

        static void RuptureDeStock(MySqlConnection connection)
        {
            //Liste contenant les numéro de produit des pièces de vélomax
            List<string> liste_Piece_Disponible = new List<string>();
            List<string> liste_Piece_Necessaire = new List<string>();
           
            connection.Open();

            MySqlCommand command = connection.CreateCommand();
            command.CommandText = "SELECT numeroProduit "
                                + "FROM Piece_rechange p;";

            MySqlDataReader reader;
            reader = command.ExecuteReader();

            string numeroProduit;

            while (reader.Read())   // parcours ligne par ligne
            {
                numeroProduit = reader.GetString(0); // récupération 1ère colonne
                liste_Piece_Disponible.Add(numeroProduit);

                Console.WriteLine(numeroProduit);
            }

            connection.Close();

            //Cadre
            liste_Piece_Necessaire.Add("C32");
            liste_Piece_Necessaire.Add("C34");
            liste_Piece_Necessaire.Add("C76");
            liste_Piece_Necessaire.Add("C43");
            liste_Piece_Necessaire.Add("C44f");
            liste_Piece_Necessaire.Add("C43f");
            liste_Piece_Necessaire.Add("C01");
            liste_Piece_Necessaire.Add("C02");
            liste_Piece_Necessaire.Add("C15");
            liste_Piece_Necessaire.Add("C87");
            liste_Piece_Necessaire.Add("C87f");
            liste_Piece_Necessaire.Add("C25");
            liste_Piece_Necessaire.Add("C26");

            //Guidon
            liste_Piece_Necessaire.Add("G7");
            liste_Piece_Necessaire.Add("G9");
            liste_Piece_Necessaire.Add("G12");

            //Freins
            liste_Piece_Necessaire.Add("F3");
            liste_Piece_Necessaire.Add("F3");

            //Selle
            liste_Piece_Necessaire.Add("S88");
            liste_Piece_Necessaire.Add("S37");
            liste_Piece_Necessaire.Add("S35");
            liste_Piece_Necessaire.Add("S02");
            liste_Piece_Necessaire.Add("S03");
            liste_Piece_Necessaire.Add("S36");
            liste_Piece_Necessaire.Add("S34");
            liste_Piece_Necessaire.Add("S87");

            //Dérailleurs Avant
            liste_Piece_Necessaire.Add("DV133");
            liste_Piece_Necessaire.Add("DV132");
            liste_Piece_Necessaire.Add("DV17");
            liste_Piece_Necessaire.Add("DV87");
            liste_Piece_Necessaire.Add("DV57");
            liste_Piece_Necessaire.Add("DV15");
            liste_Piece_Necessaire.Add("DV41");

            //Dérailleurs Arrière
            liste_Piece_Necessaire.Add("DR56");
            liste_Piece_Necessaire.Add("DR87");
            liste_Piece_Necessaire.Add("DR86");
            liste_Piece_Necessaire.Add("DR23");
            liste_Piece_Necessaire.Add("DR76");
            liste_Piece_Necessaire.Add("DR52");

            //Roue
            liste_Piece_Necessaire.Add("R1");
            liste_Piece_Necessaire.Add("R2");
            liste_Piece_Necessaire.Add("R11");
            liste_Piece_Necessaire.Add("R12");
            liste_Piece_Necessaire.Add("R18");
            liste_Piece_Necessaire.Add("R19");
            liste_Piece_Necessaire.Add("R32");
            liste_Piece_Necessaire.Add("R44");
            liste_Piece_Necessaire.Add("R45");
            liste_Piece_Necessaire.Add("R46");
            liste_Piece_Necessaire.Add("R47");
            liste_Piece_Necessaire.Add("R48");

            //Réflecteurs
            liste_Piece_Necessaire.Add("R02");
            liste_Piece_Necessaire.Add("R09");
            liste_Piece_Necessaire.Add("R10");

            //Pédalier
            liste_Piece_Necessaire.Add("P12");
            liste_Piece_Necessaire.Add("P34");
            liste_Piece_Necessaire.Add("P1");
            liste_Piece_Necessaire.Add("P15");

            //Ordinateur
            liste_Piece_Necessaire.Add("O2");
            liste_Piece_Necessaire.Add("O4");

            //Panier
            liste_Piece_Necessaire.Add("S01");
            liste_Piece_Necessaire.Add("S05");
            liste_Piece_Necessaire.Add("S74");
            liste_Piece_Necessaire.Add("S73");


            List<string> liste_Piece_A_Acheter = liste_Piece_Necessaire;

            foreach (string piece in liste_Piece_Disponible)
                liste_Piece_A_Acheter.Remove(piece);
            Console.WriteLine("Attention, " + liste_Piece_A_Acheter.Count + " pièces de sont pas disponible");
            Console.WriteLine("Voici les pièces en rupture de stock");
            foreach (string piece in liste_Piece_A_Acheter)
                Console.WriteLine(piece);

            Console.WriteLine("Nous vous suggérons d'aller vous approvisionner chez l'un de vos fournisseurs");





        }

        static void parFournisseur(MySqlConnection connection)
        //Gestion des stocks par fournisseur
        {
            connection.Open();

            MySqlCommand command = connection.CreateCommand();
            command.CommandText =
                "SELECT f.nomEntreprise , count(*) as Nombre_de_pieces_differentes_venant_de_ce_fourisseur "
                + "FROM Piece_rechange p NATURAL JOIN fournisseur f "
                + "GROUP BY p.siretFournisseur;";

            MySqlDataReader reader;
            reader = command.ExecuteReader();

            string nomEntreprise;
            int Nombre = 0;

            while (reader.Read())// parcours ligne par ligne
            {
                // prix = Convert.ToInt32(Console.ReadLine());
                nomEntreprise = reader.GetString(0);  // récupération de la 1ère colonne (il n'y en a qu'une dans la requête !)
                Nombre = reader.GetInt32(1);
                //Console.WriteLine(marque);
                Console.WriteLine(nomEntreprise + " : " + Nombre);
            }

            connection.Close();

            connection.Open();

            Console.WriteLine("Pour quel fournisseur souhaitez-vous connaitre plus de détails ? (Scott, Trek )");
            string fournisseur = Console.ReadLine();
            command = connection.CreateCommand();
            command.CommandText =
                "SELECT * "
                + "FROM Piece_rechange p, fournisseur f "
                + "WHERE p.siretFournisseur = f.siretFournisseur and f.nomEntreprise = '" + fournisseur + "';";

            reader = command.ExecuteReader();

            string numeroProduit;
            string description;
            string date_intro;
            string date_discont_prod;
            int delai_approvisionnement;
            string numero_produit_fournisseur;
            string siretFournisseur;
            string contact;
            string adresse;
            string libelle;





            while (reader.Read())// parcours ligne par ligne
            {
                numeroProduit = reader.GetString(0);
                description = reader.GetString(1);
                date_intro = reader.GetString(2);
                date_discont_prod = reader.GetString(3);
                delai_approvisionnement = reader.GetInt32(4);
                numero_produit_fournisseur = reader.GetString(5);
                siretFournisseur = reader.GetString(6);
                nomEntreprise = reader.GetString(7);
                contact = reader.GetString(9);
                adresse = reader.GetString(10);
                libelle = reader.GetString(11);

                Console.WriteLine(numeroProduit + " : " + description + " , " + date_intro + " , " + date_discont_prod + " , " + delai_approvisionnement + " , " + numero_produit_fournisseur + " , " + siretFournisseur + " , " + nomEntreprise + " , " + contact + " , " + adresse + " , " + libelle);
            }



            connection.Close();
        }

        static void parVelo(MySqlConnection connection)
        //Gestion des stocks vélo
        {
            connection.Open();

            MySqlCommand command = connection.CreateCommand();
            command.CommandText =
                "SELECT nomB, count(*) as Nombre "
                + "FROM Modele_Bicyclette m "
                + "GROUP BY m.nomB;";

            MySqlDataReader reader;
            reader = command.ExecuteReader();

            string nomB;
            int Nombre = 0;

            while (reader.Read())// parcours ligne par ligne
            {
                nomB = reader.GetString(0);  // récupération de la 1ère colonne (il n'y en a qu'une dans la requête !)
                Nombre = reader.GetInt32(1);
                Console.WriteLine(nomB + " : " + Nombre);
            }

            connection.Close();

            connection.Open();

            Console.WriteLine("Pour quel vélo souhaitez-vous connaitre plus de détails ? (Kilimanjaro, NorthPole, MontBlanc, Hooligan, Orléans, BlueJay, Trail Explorer, Night Hawk, Tierra Verde, Mud Zinger I, Mud Zinger II )");
            string velo = Console.ReadLine();
            command = connection.CreateCommand();
            command.CommandText =
                "SELECT * "
                + "FROM Modele_Bicyclette m "
                + "WHERE m.nomB = '" + velo + "';";

            reader = command.ExecuteReader();

            int numModele;
            int prixUnitaire;
            string ligne_produit;
            string date_intro;
            string date_discont_prod;
            string grandeur;
            /*string cadre;
            string freins;
            string guidon;
            string selle;
            string derailleur_Avant;
            string derailleur_Arrière;
            string roue_Avant;
            string roue_Arrière;
            string reflecteurs;
            string pedalier;
            string ordinateur;
            string panier;*/

            while (reader.Read())// parcours ligne par ligne
            {
                numModele = reader.GetInt32(0);
                nomB = reader.GetString(1);
                prixUnitaire = reader.GetInt32(2);
                ligne_produit = reader.GetString(3);
                date_intro = reader.GetString(4);
                date_discont_prod = reader.GetString(5);
                grandeur = reader.GetString(6);
                //cadre = reader.GetString(7);
                //freins = reader.GetString(8);

                // Parfois guidon est null et dans ce case .GetString renvoie une erreur

                /*guidon = reader.GetString(9);
                selle = reader.GetString(10);
                derailleur_Avant = reader.GetString(11);
                derailleur_Arrière = reader.GetString(12);
                roue_Avant = reader.GetString(13);
                roue_Arrière = reader.GetString(14);
                reflecteurs = reader.GetString(15);
                pedalier = reader.GetString(16);
                ordinateur = reader.GetString(17);
                panier = reader.GetString(18);*/


                Console.WriteLine(numModele + " : " + nomB + " , " + prixUnitaire + " , " + ligne_produit + " , " + date_intro + " , " + date_discont_prod + " , " + grandeur);// + " , " + guidon + " , " + freins + " , " + selle + " , " + derailleur_Avant + " , " + derailleur_Arrière + " , " + roue_Avant + " , " + roue_Arrière + " , " + reflecteurs + " , " + pedalier + " , " + ordinateur + " , " + panier);
            }



            connection.Close();
        }


        static void parCategorieVelo(MySqlConnection connection)
        //Gestion des stocks par catégorie de vélo
        {
            connection.Open();

            MySqlCommand command = connection.CreateCommand();
            command.CommandText =
                "SELECT ligne_produit, count(*) as Nombre "
                + "FROM Modele_Bicyclette m "
                + "GROUP BY m.ligne_produit;";

            MySqlDataReader reader;
            reader = command.ExecuteReader();

            string ligne_produit;
            int Nombre = 0;

            while (reader.Read())// parcours ligne par ligne
            {
                ligne_produit = reader.GetString(0);  // récupération de la 1ère colonne (il n'y en a qu'une dans la requête !)
                Nombre = reader.GetInt32(1);
                Console.WriteLine(ligne_produit + " : " + Nombre);
            }

            connection.Close();

            connection.Open();

            Console.WriteLine("Pour quel catégorie de vélo souhaitez-vous connaitre plus de détails ? ( VTT, Vélo de course, Classique, BMX )");
            string categorie = Console.ReadLine();
            command = connection.CreateCommand();
            command.CommandText =
                "SELECT * "
                + "FROM Modele_Bicyclette m "
                + "WHERE m.ligne_produit = '" + categorie + "';";

            reader = command.ExecuteReader();

            int numModele;
            int prixUnitaire;
            string nomB;
            string date_intro;
            string date_discont_prod;
            string grandeur;
            /*string cadre;
            string freins;
            string guidon;
            string selle;
            string derailleur_Avant;
            string derailleur_Arrière;
            string roue_Avant;
            string roue_Arrière;
            string reflecteurs;
            string pedalier;
            string ordinateur;
            string panier;*/

            while (reader.Read())// parcours ligne par ligne
            {
                numModele = reader.GetInt32(0);
                nomB = reader.GetString(1);
                prixUnitaire = reader.GetInt32(2);
                ligne_produit = reader.GetString(3);
                date_intro = reader.GetString(4);
                date_discont_prod = reader.GetString(5);
                grandeur = reader.GetString(6);
                //cadre = reader.GetString(7);
                //freins = reader.GetString(8);

                // Parfois guidon est null et dans ce case .GetString renvoie une erreur

                /*guidon = reader.GetString(9);
                selle = reader.GetString(10);
                derailleur_Avant = reader.GetString(11);
                derailleur_Arrière = reader.GetString(12);
                roue_Avant = reader.GetString(13);
                roue_Arrière = reader.GetString(14);
                reflecteurs = reader.GetString(15);
                pedalier = reader.GetString(16);
                ordinateur = reader.GetString(17);
                panier = reader.GetString(18);*/


                Console.WriteLine(numModele + " : " + nomB + " , " + prixUnitaire + " , " + ligne_produit + " , " + date_intro + " , " + date_discont_prod + " , " + grandeur);// + " , " + guidon + " , " + freins + " , " + selle + " , " + derailleur_Avant + " , " + derailleur_Arrière + " , " + roue_Avant + " , " + roue_Arrière + " , " + reflecteurs + " , " + pedalier + " , " + ordinateur + " , " + panier);
            }



            connection.Close();
        }



        static void parGrandeur(MySqlConnection connection)
        //Gestion des stocks par grandeur
        {
            connection.Open();

            MySqlCommand command = connection.CreateCommand();
            command.CommandText =
                "SELECT grandeur, count(*) as Nombre "
                + "FROM Modele_Bicyclette m "
                + "GROUP BY m.grandeur;";

            MySqlDataReader reader;
            reader = command.ExecuteReader();

            string grandeur;
            int Nombre = 0;

            while (reader.Read())// parcours ligne par ligne
            {
                grandeur = reader.GetString(0);  // récupération de la 1ère colonne (il n'y en a qu'une dans la requête !)
                Nombre = reader.GetInt32(1);
                Console.WriteLine(grandeur + " : " + Nombre);
            }

            connection.Close();

            connection.Open();

            Console.WriteLine("Pour quel type de vélo souhaitez-vous connaitre plus de détails ? ( Adultes, Jeunes, Hommes, Dames, Filles, Garçons )");
            string type = Console.ReadLine();
            command = connection.CreateCommand();
            command.CommandText =
                "SELECT * "
                + "FROM Modele_Bicyclette m "
                + "WHERE m.grandeur = '" + type + "';";

            reader = command.ExecuteReader();

            int numModele;
            int prixUnitaire;
            string nomB;
            string date_intro;
            string date_discont_prod;
            string ligne_produit;
            /*string cadre;
            string freins;
            string guidon;
            string selle;
            string derailleur_Avant;
            string derailleur_Arrière;
            string roue_Avant;
            string roue_Arrière;
            string reflecteurs;
            string pedalier;
            string ordinateur;
            string panier;*/

            while (reader.Read())// parcours ligne par ligne
            {
                numModele = reader.GetInt32(0);
                nomB = reader.GetString(1);
                prixUnitaire = reader.GetInt32(2);
                ligne_produit = reader.GetString(3);
                date_intro = reader.GetString(4);
                date_discont_prod = reader.GetString(5);
                grandeur = reader.GetString(6);
                //cadre = reader.GetString(7);
                //freins = reader.GetString(8);

                // Parfois guidon est null et dans ce case .GetString renvoie une erreur

                /*guidon = reader.GetString(9);
                selle = reader.GetString(10);
                derailleur_Avant = reader.GetString(11);
                derailleur_Arrière = reader.GetString(12);
                roue_Avant = reader.GetString(13);
                roue_Arrière = reader.GetString(14);
                reflecteurs = reader.GetString(15);
                pedalier = reader.GetString(16);
                ordinateur = reader.GetString(17);
                panier = reader.GetString(18);*/


                Console.WriteLine(numModele + " : " + nomB + " , " + prixUnitaire + " , " + ligne_produit + " , " + date_intro + " , " + date_discont_prod + " , " + grandeur);// + " , " + guidon + " , " + freins + " , " + selle + " , " + derailleur_Avant + " , " + derailleur_Arrière + " , " + roue_Avant + " , " + roue_Arrière + " , " + reflecteurs + " , " + pedalier + " , " + ordinateur + " , " + panier);
            }



            connection.Close();
        }

        static void parPrixUnitaire(MySqlConnection connection)
        //Gestion des stocks par prix unitaire
        {
            connection.Open();

            MySqlCommand command = connection.CreateCommand();
            command.CommandText =
                "SELECT prixUnitaire, count(*) as Nombre "
                + "FROM Modele_Bicyclette m "
                + "GROUP BY m.prixUnitaire;";

            MySqlDataReader reader;
            reader = command.ExecuteReader();

            int prixUnitaire;
            int Nombre = 0;

            while (reader.Read())// parcours ligne par ligne
            {
                prixUnitaire = reader.GetInt32(0);  // récupération de la 1ère colonne (il n'y en a qu'une dans la requête !)
                Nombre = reader.GetInt32(1);
                Console.WriteLine(prixUnitaire + " : " + Nombre);
            }

            connection.Close();

            connection.Open();

            Console.WriteLine("Pour quel prix maximal de vélo souhaitez-vous connaitre plus de détails ? (en euros)");
            int prix = Convert.ToInt32(Console.ReadLine());
            command = connection.CreateCommand();
            command.CommandText =
                "SELECT * "
                + "FROM Modele_Bicyclette m "
                + "WHERE m.prixUnitaire <= " + prix + ";";

            reader = command.ExecuteReader();

            int numModele;
            string grandeur;
            string nomB;
            string date_intro;
            string date_discont_prod;
            string ligne_produit;
            /*string cadre;
            string freins;
            string guidon;
            string selle;
            string derailleur_Avant;
            string derailleur_Arrière;
            string roue_Avant;
            string roue_Arrière;
            string reflecteurs;
            string pedalier;
            string ordinateur;
            string panier;*/

            while (reader.Read())// parcours ligne par ligne
            {
                numModele = reader.GetInt32(0);
                nomB = reader.GetString(1);
                prixUnitaire = reader.GetInt32(2);
                ligne_produit = reader.GetString(3);
                date_intro = reader.GetString(4);
                date_discont_prod = reader.GetString(5);
                grandeur = reader.GetString(6);
                //cadre = reader.GetString(7);
                //freins = reader.GetString(8);

                // Parfois guidon est null et dans ce case .GetString renvoie une erreur

                /*guidon = reader.GetString(9);
                selle = reader.GetString(10);
                derailleur_Avant = reader.GetString(11);
                derailleur_Arrière = reader.GetString(12);
                roue_Avant = reader.GetString(13);
                roue_Arrière = reader.GetString(14);
                reflecteurs = reader.GetString(15);
                pedalier = reader.GetString(16);
                ordinateur = reader.GetString(17);
                panier = reader.GetString(18);*/


                Console.WriteLine(numModele + " : " + nomB + " , " + prixUnitaire + " , " + ligne_produit + " , " + date_intro + " , " + date_discont_prod + " , " + grandeur);// + " , " + guidon + " , " + freins + " , " + selle + " , " + derailleur_Avant + " , " + derailleur_Arrière + " , " + roue_Avant + " , " + roue_Arrière + " , " + reflecteurs + " , " + pedalier + " , " + ordinateur + " , " + panier);
            }



            connection.Close();
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        static void ListeMembrePourChaqueProgramme(MySqlConnection connection)
        //Module statistique
        {
            connection.Open();

            MySqlCommand command = connection.CreateCommand();
            MySqlDataReader reader;

            Console.WriteLine("Pour quel programme d'admission souhaitez-vous connaitre les membres ? (1,2,3,4)");
            int num = Convert.ToInt32(Console.ReadLine());
            command = connection.CreateCommand();
            command.CommandText =
                "SELECT numSecu, prenom "
                + "FROM Particulier p "
                + "WHERE p.noProgramme = " + num + ";";

            reader = command.ExecuteReader();

            string numSecu;
            string prenom;

            while (reader.Read())// parcours ligne par ligne
            {
                // prix = Convert.ToInt32(Console.ReadLine());
                numSecu = reader.GetString(0);
                prenom = reader.GetString(1);

                //Console.WriteLine(marque);
                Console.WriteLine("Numéro de sécurité sociale : " + numSecu);
                Console.WriteLine("Prénom : " + prenom);

            }



            connection.Close();
        }

        static void NombreClient(MySqlConnection connection)
        {
            connection.Open();

            MySqlCommand command = connection.CreateCommand();
            MySqlDataReader reader;

            command = connection.CreateCommand();
            command.CommandText =
                "SELECT count(*) "
                + "FROM Client c;";

            reader = command.ExecuteReader();

            int nbClient = 0;

            while (reader.Read())// parcours ligne par ligne
            {
                nbClient = reader.GetInt32(0);
                Console.WriteLine("Vous avez " + nbClient + " clients");
            }



            connection.Close();
        }

        static void CreationFournisseur(MySqlConnection connection)
        {
            connection.Open();

            MySqlCommand command = connection.CreateCommand();
           
            
            Console.WriteLine("Saisir le nom");
            string nom = Console.ReadLine();
            Console.WriteLine("Saisir le siret");
            string siret = Console.ReadLine();
            Console.WriteLine("Saisir le numéro de téléphone");
            string tel = Console.ReadLine();
            Console.WriteLine("Saisir l'adresse");
            string adresse = Console.ReadLine();
            Console.WriteLine("Saisir le libelle (1,2,3,4)");
            int libelle = Convert.ToInt32(Console.ReadLine());

            
            command.CommandText = "INSERT INTO Fournisseur VALUE(@Nom,@Siret,@tel,@adresse,@libelle);";
            command.Parameters.Add(new MySqlParameter("@Nom", nom));
            command.Parameters.Add(new MySqlParameter("@Siret", siret));
            command.Parameters.Add(new MySqlParameter("@tel", tel));
            command.Parameters.Add(new MySqlParameter("@adresse", adresse));
            command.Parameters.Add(new MySqlParameter("@libelle", libelle));
            command.ExecuteNonQuery();
            connection.Close();
        }

        static void AffichageFournisseur(MySqlConnection connection)
        {
           connection.Open();
            MySqlCommand command = connection.CreateCommand();
            MySqlDataReader reader;

            command = connection.CreateCommand();
            command.CommandText =
                "SELECT * FROM Fournisseur;";
            reader = command.ExecuteReader();
            while(reader.Read())
            {
                Console.WriteLine("---------------------------------");
                Console.WriteLine("Nom :" + reader.GetString(0));
                Console.WriteLine("Siret :" + reader.GetString(1));
                Console.WriteLine("Numéro de téléphone :" + reader.GetString(2));
                Console.WriteLine("Adresse :" + reader.GetString(3));
                Console.WriteLine("Libelle :" + reader.GetInt32(4));
                Console.WriteLine("---------------------------------");
            }
            connection.Close();
        }

        static void MiseAJourFournisseur(MySqlConnection connection)
        {
            
            MySqlCommand command = connection.CreateCommand();
            
            command = connection.CreateCommand();
            Console.WriteLine("Liste des Fournisseurs");
            Console.WriteLine("");
            AffichageFournisseur(connection);
            Console.WriteLine("Saisir le siret du fournisseur à mettre à jour");
            string siret = Console.ReadLine();
            Console.Clear();
            Console.WriteLine("Saisir 1 pour actualiser le nom");
            Console.WriteLine("Saisir 2 pour actualiser l'adresse");
            Console.WriteLine("Saisir 3 pour actualiser le numero de téléphone");
            Console.WriteLine("Saisir 4 pour actualiser le libelle");
            int nb = Convert.ToInt32(Console.ReadLine());
            switch (nb)
            {
                case 1:
                    connection.Open();
                    command.CommandText = "UPDATE Fournisseur set nomEntreprise = @nom where siretFournisseur=@siret";
                    Console.WriteLine("Saisir le nouveau nom");
                    string nom = Console.ReadLine();
                    command.Parameters.Add(new MySqlParameter("@siret", siret));
                    command.Parameters.Add(new MySqlParameter("@nom", nom));
                    command.ExecuteNonQuery();
                    
                    break;
                case 2:
                    connection.Open();
                    command.CommandText = "UPDATE Fournisseur set adresse = @adresse where siretFournisseur=@siret";
                    Console.WriteLine("Saisir la nouvelle adresse");
                    string adresse = Console.ReadLine();
                    command.Parameters.Add(new MySqlParameter("@siret", siret));
                    command.Parameters.Add(new MySqlParameter("@adresse", adresse));
                    command.ExecuteNonQuery();
                    break;
                case 3:
                    connection.Open();
                    command.CommandText = "UPDATE Fournisseur set contact = @contact where siretFournisseur=@siret";
                    Console.WriteLine("Saisir le nouveau numéro de téléphone");
                    string contact = Console.ReadLine();
                    command.Parameters.Add(new MySqlParameter("@siret", siret));
                    command.Parameters.Add(new MySqlParameter("@contact", contact));
                    command.ExecuteNonQuery();
                    break;
                case 4:
                    connection.Open();
                    command.CommandText = "UPDATE Fournisseur set libelle = @libelle where siretFournisseur=@siret";
                    Console.WriteLine("Saisir le nouveau libelle");
                    int libelle = Convert.ToInt32(Console.ReadLine());
                    command.Parameters.Add(new MySqlParameter("@siret", siret));
                    command.Parameters.Add(new MySqlParameter("@libelle", libelle));
                    command.ExecuteNonQuery();
                    break;

                default:
                    { Console.WriteLine("Choix indisponible"); break; }
            }
            connection.Close();
        }

        static void SuppressionFournisseur(MySqlConnection connection)
        {
            
            MySqlCommand command1 = connection.CreateCommand();
            MySqlCommand command2 = connection.CreateCommand();
            command1 = connection.CreateCommand();
            command2 = connection.CreateCommand();
            Console.WriteLine("Liste des Fournisseurs");
            Console.WriteLine("");
            AffichageFournisseur(connection);
            Console.WriteLine("Saisir le siret du fournisseur à supprimer");
            string siret = Console.ReadLine();
            connection.Open();
            command1.CommandText = "DELETE FROM Fournisseur where siretFournisseur=@siret";
            command1.Parameters.Add(new MySqlParameter("@siret", siret));
            command2.CommandText = "DELETE FROM Piece_rechange p where p.siretFournisseur=@siret";
            command2.Parameters.Add(new MySqlParameter("@siret", siret));
            command2.ExecuteNonQuery();
            command1.ExecuteNonQuery();            
            connection.Close();
        }

        static void CreationPiece(MySqlConnection connection)
        {
            AffichageFournisseur(connection);
            connection.Open();
            MySqlCommand command = connection.CreateCommand();
            Console.WriteLine("Saisir le numero de produit");
            string num = Console.ReadLine();
            Console.WriteLine("Saisir la description");
            string description = Console.ReadLine();
            Console.WriteLine("Saisir la date d'introduction");
            string dateintro = Console.ReadLine();
            Console.WriteLine("Saisir la date de discontinuation");
            string datedisc = Console.ReadLine();
            Console.WriteLine("Saisir le delai d'aprovisionnement");
            int delai = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Saisir le numéro produit au catalogue du fournisseur");
            string numProdF = Console.ReadLine();
            Console.WriteLine("Saisir le siret du fournisseur");
            string siret = Console.ReadLine();
            command.CommandText = "INSERT INTO Piece_rechange VALUE(@numeroProduit,@description,@date_intro,@date_discont_prod,@delai_approvisionnement,@numero_produit_fournisseur,@siretFournisseur);";
            command.Parameters.Add(new MySqlParameter("@numeroProduit", num));
            command.Parameters.Add(new MySqlParameter("@description", description));
            command.Parameters.Add(new MySqlParameter("@date_intro", dateintro));
            command.Parameters.Add(new MySqlParameter("@date_discont_prod", datedisc));
            command.Parameters.Add(new MySqlParameter("@delai_approvisionnement", delai));
            command.Parameters.Add(new MySqlParameter("@numero_produit_fournisseur", numProdF));
            command.Parameters.Add(new MySqlParameter("@siretFournisseur", siret));
            command.ExecuteNonQuery();
            connection.Close();
        }

        static void AffichagePiece(MySqlConnection connection)
        {
            connection.Open();
            MySqlCommand command = connection.CreateCommand();
            MySqlDataReader reader;

            command = connection.CreateCommand();
            command.CommandText =
                "SELECT * FROM Piece_rechange;";
            reader = command.ExecuteReader();
            while (reader.Read())
            {
                Console.WriteLine("---------------------------------");
                Console.WriteLine("numero du produit :" + reader.GetString(0));
                Console.WriteLine("description :" + reader.GetString(1));
                Console.WriteLine("date d'introduction :" + reader.GetString(2));
                Console.WriteLine("date de discontinuation de production :" + reader.GetString(3));
                Console.WriteLine("Délai d'aprovisionnement :" + reader.GetInt32(4));
                Console.WriteLine("Numero du produit chez le fournisseur :" + reader.GetString(5));
                Console.WriteLine("Siret du fournisseur :" + reader.GetString(6));
                Console.WriteLine("---------------------------------");
            }
            connection.Close();
        }

        static void SuppressionPiece(MySqlConnection connection)
        {
            Console.WriteLine("Liste des pieces");
            Console.WriteLine("");
            AffichagePiece(connection);
            connection.Open();
            Console.WriteLine("Saisir le numéro de la pièce à suprimer");
            string num = Console.ReadLine();
            MySqlCommand command1 = connection.CreateCommand();
            command1.CommandText = "DELETE FROM Piece_rechange p where p.numeroProduit=@numeroProduit";
            command1.Parameters.Add(new MySqlParameter("@numeroProduit", num));
            connection.Close();
        }

        static void ModificationPiece(MySqlConnection connection)
        {
            MySqlCommand command = connection.CreateCommand();

            command = connection.CreateCommand();
            Console.WriteLine("Liste des produits");
            Console.WriteLine("");
            AffichageFournisseur(connection);
            Console.WriteLine("Saisir le numéro du produit à mettre à jour");
            string num = Console.ReadLine();
            Console.Clear();
            Console.WriteLine("Saisir 1 pour actualiser le délai d'aprovisionnement");
            Console.WriteLine("Saisir 2 pour actualiser le numéro de produit chez le fournisseur");
            Console.WriteLine("Saisir 3 pour actualiser le siret du fournisseur");
            
            int nb = Convert.ToInt32(Console.ReadLine());
            switch(nb)
            {
                case 1:
                    Console.WriteLine("Saisir le nouveau délai");
                    int delai = Convert.ToInt32(Console.ReadLine());
                    connection.Open();
                    command.CommandText = "UPDATE Piece_rechange set delai_approvisionnement = @delai where numeroProduit=@num";
                    command.Parameters.Add(new MySqlParameter("@delai", delai));
                    command.Parameters.Add(new MySqlParameter("@num", num));
                    command.ExecuteNonQuery();                    
                    break;
                case 2:
                    Console.WriteLine("Saisir le nouveau numéro de produit chez le fournisseur");
                    string numF = Console.ReadLine();
                    connection.Open();
                    command.CommandText = "UPDATE Piece_rechange set numero_produit_fournisseur = @numF where numeroProduit=@num";
                    command.Parameters.Add(new MySqlParameter("@numF", numF));
                    command.Parameters.Add(new MySqlParameter("@num", num));
                    command.ExecuteNonQuery();
                    break;
                case 3:
                    Console.WriteLine("Saisir le siret du nouveau fournisseur");
                    string siret = Console.ReadLine();
                    connection.Open();
                    command.CommandText = "UPDATE Piece_rechange set siretFournisseur = @siret where numeroProduit=@num";
                    command.Parameters.Add(new MySqlParameter("@siret", siret));
                    command.Parameters.Add(new MySqlParameter("@num", num));
                    command.ExecuteNonQuery();
                    break;
                default:
                    { Console.WriteLine("Choix indisponible"); break; }
            }
            connection.Close();
        }
    }
}//class Programm


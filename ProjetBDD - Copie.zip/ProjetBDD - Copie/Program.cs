﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetBDD
{
    using MySql.Data.MySqlClient;
    using System.IO;

    class Program
    {
        static void Main(string[] args)
        {

            string connectionString = "SERVER=localhost;PORT=3306;DATABASE=velomax;UID=root;PASSWORD=me28ra96;SSLMODE=none;";
            MySqlConnection connection = new MySqlConnection(connectionString);

            /*Console.Clear();
            Console.WriteLine("0 Lecture/ecriture de fichier csv");
            Console.WriteLine("=================\n");
            Exo0();
            Console.WriteLine("\nappuyez sur une touche pour continuer");
            Console.ReadKey();*/


            Console.WriteLine("fin des opérations");

            Console.Clear();
            Console.WriteLine("1.1 Liste des marques");
            Console.WriteLine("=================");
            Exo1(connection);
            Console.WriteLine("\nappuyez sur une touche pour continuer");
            Console.ReadKey();

            Console.Clear();
            Console.WriteLine("\n\n1.2 Liste des propriétaires avec véhicules");
            Console.WriteLine("=================");
            RuptureDeStock(connection);
            Console.WriteLine("\nappuyez sur une touche pour continuer");
            Console.ReadKey();

            Console.Clear();
            Console.WriteLine("\n\n1.3 Liste des véhicules par prix de journée décroissant");
            Console.WriteLine("=================");
            Exo3(connection);
            Console.WriteLine("\nappuyez sur une touche pour continuer");
            Console.ReadKey();

            Console.Clear();
            Console.WriteLine("\n\n1.4 Valeur moyenne des prix de journée");
            Console.WriteLine("=================");
            Exo4(connection);
            Console.WriteLine("\nappuyez sur une touche pour continuer");
            Console.ReadKey();

            Console.Clear();
            Console.WriteLine("\n\n1.6 deuxième prix de journée minimum");
            Console.WriteLine("\n=================");
            Exo6(connection);
            Console.WriteLine("appuyez sur une touche pour continuer");
            Console.ReadKey();
            Console.WriteLine("\n1.6 deuxième prix de journée minimum version 2");
            Console.WriteLine("\n=================");


            Console.Clear();
            Console.WriteLine("\n\n1.7 prix de journée médian");
            Console.WriteLine("\n=================");
            Exo7(connection);
            Console.WriteLine("appuyez sur une touche pour finir\n");

            Console.Clear();
            Console.WriteLine("\n\n1.7 prix de journée médian");
            Console.WriteLine("\n=================");
            Exo8(connection);
            Console.WriteLine("appuyez sur une touche pour finir\n");

            Console.ReadKey();

        }//main

        static void Exo0()
        {
            //lire le fichier clients.csv
            Console.WriteLine("Lecture du fichier clients.csv");
            Console.WriteLine("----------------------------");
            string nomFichier = "clients.csv";
            Lire(nomFichier);
            Console.WriteLine("----------------------------");
            Console.WriteLine("Appuyez sur une touche pour continuer...\n");
            Console.ReadKey();
            //
            // ecrire dans le fichier csv
            // le client supplémentaire
            Console.WriteLine("Ecriture dans le fichier clients.csv");
            Console.WriteLine("----------------------------");
            string nom = "Jouvet";
            string prenom = "Louis";
            int age = 80;
            string numPermis = "55555";
            string adresse = "rue du vent";
            string ville = "Paris";
            string newClient = nom + ";"
                + prenom + ";"
                + Convert.ToString(age) + ";"
                + numPermis + ";"
                + adresse + ";"
                + ville;
            bool append = true;
            Ecrire(newClient, nomFichier, append);

            //relire le fichier clients.csv
            Console.WriteLine("Relecture du fichier clients.csv");
            Console.WriteLine("----------------------------");
            Lire(nomFichier);
            Console.WriteLine("----------------------------\n");

        }
        static void Ecrire(string ligne, string fichier, bool append)
        {
            StreamWriter ecrire = new StreamWriter(fichier, true);
            ecrire.WriteLine(ligne);
            ecrire.Close();
        }
        static void Lire(string fichier)
        {
            string ligne = "";
            char[] sep = new char[1] { '1' };
            string[] datas = new string[6];

            StreamReader lecteur = new StreamReader(fichier);
            while (lecteur.Peek() > 0)
            {
                ligne = lecteur.ReadLine();
                Console.WriteLine("ligne lu " + ligne);
                datas = ligne.Split(';');
                //datas = ligne.Split(sep);
            }
            lecteur.Close();
        }



        static void Exo1(MySqlConnection connection)
        //Gestion des stocks pas pièce
        {
            connection.Open();

            MySqlCommand command = connection.CreateCommand();
            command.CommandText =
                "SELECT description , count(*) as Nombre "
                + "FROM Piece_rechange p "
                + "GROUP BY p.description;";
            //" SELECT DISTINCT(marque) FROM voiture ;";

            MySqlDataReader reader;
            reader = command.ExecuteReader();

            string description;
            int Nombre = 0;

            while (reader.Read())// parcours ligne par ligne
            {
                // prix = Convert.ToInt32(Console.ReadLine());
                description = reader.GetString(0);  // récupération de la 1ère colonne (il n'y en a qu'une dans la requête !)
                Nombre = reader.GetInt32(1);
                //Console.WriteLine(marque);
                Console.WriteLine(description + " : " + Nombre);
            }

            connection.Close();

            connection.Open();

            Console.WriteLine("Pour quel pièce souhaitez-vous connaitre plus de détails ? ( cadre, guidon, freins, selle, derailleur avant, derailleur arrière, roue arrière, reflecteurs, pedalier, ordinateur, panier)");
            string piece = Console.ReadLine();
            command = connection.CreateCommand();
            command.CommandText =
                "SELECT *"
                + "FROM Piece_rechange p "
                + "WHERE p.description = '" + piece + "';";

            reader = command.ExecuteReader();

            string numeroProduit;
            string date_intro;
            string date_discont_prod;
            int delai_approvisionnement;
            string numero_produit_fournisseur;
            string siretFournisseur;


            


            while (reader.Read())// parcours ligne par ligne
            {
                // prix = Convert.ToInt32(Console.ReadLine());
                numeroProduit = reader.GetString(0);
                description = reader.GetString(1);
                date_intro = reader.GetString(2);
                date_discont_prod = reader.GetString(3);
                delai_approvisionnement = reader.GetInt32(4);
                numero_produit_fournisseur = reader.GetString(5);
                siretFournisseur = reader.GetString(6);

                //Console.WriteLine(marque);
                Console.WriteLine(numeroProduit + " : " + description + " , " + date_intro + " , " + date_discont_prod + " , " + delai_approvisionnement + " , " + numero_produit_fournisseur + " , " + siretFournisseur);
            }



            connection.Close();
        }

        static void RuptureDeStock(MySqlConnection connection)
        {
            //Liste contenant les numéro de produit des pièces de vélomax
            List<string> liste_Piece_Disponible = new List<string>();
            List<string> liste_Piece_Necessaire = new List<string>();
           
            connection.Open();

            MySqlCommand command = connection.CreateCommand();
            command.CommandText = "SELECT numeroProduit "
                                + "FROM Piece_rechange p;";

            MySqlDataReader reader;
            reader = command.ExecuteReader();

            string numeroProduit;

            while (reader.Read())   // parcours ligne par ligne
            {
                numeroProduit = reader.GetString(0); // récupération 1ère colonne
                liste_Piece_Disponible.Add(numeroProduit);

                Console.WriteLine(numeroProduit);
            }

            connection.Close();

            //Cadre
            liste_Piece_Necessaire.Add("C32");
            liste_Piece_Necessaire.Add("C34");
            liste_Piece_Necessaire.Add("C76");
            liste_Piece_Necessaire.Add("C43");
            liste_Piece_Necessaire.Add("C44f");
            liste_Piece_Necessaire.Add("C43f");
            liste_Piece_Necessaire.Add("C01");
            liste_Piece_Necessaire.Add("C02");
            liste_Piece_Necessaire.Add("C15");
            liste_Piece_Necessaire.Add("C87");
            liste_Piece_Necessaire.Add("C87f");
            liste_Piece_Necessaire.Add("C25");
            liste_Piece_Necessaire.Add("C26");

            //Guidon
            liste_Piece_Necessaire.Add("G7");
            liste_Piece_Necessaire.Add("G9");
            liste_Piece_Necessaire.Add("G12");

            //Freins
            liste_Piece_Necessaire.Add("F3");
            liste_Piece_Necessaire.Add("F3");

            //Selle
            liste_Piece_Necessaire.Add("S88");
            liste_Piece_Necessaire.Add("S37");
            liste_Piece_Necessaire.Add("S35");
            liste_Piece_Necessaire.Add("S02");
            liste_Piece_Necessaire.Add("S03");
            liste_Piece_Necessaire.Add("S36");
            liste_Piece_Necessaire.Add("S34");
            liste_Piece_Necessaire.Add("S87");

            //Dérailleurs Avant
            liste_Piece_Necessaire.Add("DV133");
            liste_Piece_Necessaire.Add("DV132");
            liste_Piece_Necessaire.Add("DV17");
            liste_Piece_Necessaire.Add("DV87");
            liste_Piece_Necessaire.Add("DV57");
            liste_Piece_Necessaire.Add("DV15");
            liste_Piece_Necessaire.Add("DV41");

            //Dérailleurs Arrière
            liste_Piece_Necessaire.Add("DR56");
            liste_Piece_Necessaire.Add("DR87");
            liste_Piece_Necessaire.Add("DR86");
            liste_Piece_Necessaire.Add("DR23");
            liste_Piece_Necessaire.Add("DR76");
            liste_Piece_Necessaire.Add("DR52");

            //Roue
            liste_Piece_Necessaire.Add("R1");
            liste_Piece_Necessaire.Add("R2");
            liste_Piece_Necessaire.Add("R11");
            liste_Piece_Necessaire.Add("R12");
            liste_Piece_Necessaire.Add("R18");
            liste_Piece_Necessaire.Add("R19");
            liste_Piece_Necessaire.Add("R32");
            liste_Piece_Necessaire.Add("R44");
            liste_Piece_Necessaire.Add("R45");
            liste_Piece_Necessaire.Add("R46");
            liste_Piece_Necessaire.Add("R47");
            liste_Piece_Necessaire.Add("R48");

            //Réflecteurs
            liste_Piece_Necessaire.Add("R02");
            liste_Piece_Necessaire.Add("R09");
            liste_Piece_Necessaire.Add("R10");

            //Pédalier
            liste_Piece_Necessaire.Add("P12");
            liste_Piece_Necessaire.Add("P34");
            liste_Piece_Necessaire.Add("P1");
            liste_Piece_Necessaire.Add("P15");

            //Ordinateur
            liste_Piece_Necessaire.Add("O2");
            liste_Piece_Necessaire.Add("O4");

            //Panier
            liste_Piece_Necessaire.Add("S01");
            liste_Piece_Necessaire.Add("S05");
            liste_Piece_Necessaire.Add("S74");
            liste_Piece_Necessaire.Add("S73");


            List<string> liste_Piece_A_Acheter = liste_Piece_Necessaire;

            foreach (string piece in liste_Piece_Disponible)
                liste_Piece_A_Acheter.Remove(piece);
            Console.WriteLine("Attention, " + liste_Piece_A_Acheter.Count + " pièces de sont pas disponible");
            Console.WriteLine("Voici les pièces en rupture de stock");
            foreach (string piece in liste_Piece_A_Acheter)
                Console.WriteLine(piece);
            


        }

        static void Exo3(MySqlConnection connection)
        //Gestion des stocks par fournisseur
        {
            connection.Open();

            MySqlCommand command = connection.CreateCommand();
            command.CommandText =
                "SELECT f.nomEntreprise , count(*) as Nombre_de_pieces_differentes_venant_de_ce_fourisseur "
                + "FROM Piece_rechange p NATURAL JOIN fournisseur f "
                + "GROUP BY p.siretFournisseur;";

            MySqlDataReader reader;
            reader = command.ExecuteReader();

            string nomEntreprise;
            int Nombre = 0;

            while (reader.Read())// parcours ligne par ligne
            {
                // prix = Convert.ToInt32(Console.ReadLine());
                nomEntreprise = reader.GetString(0);  // récupération de la 1ère colonne (il n'y en a qu'une dans la requête !)
                Nombre = reader.GetInt32(1);
                //Console.WriteLine(marque);
                Console.WriteLine(nomEntreprise + " : " + Nombre);
            }

            connection.Close();

            connection.Open();

            Console.WriteLine("Pour quel fournisseur souhaitez-vous connaitre plus de détails ? (Scott, Trek )");
            string fournisseur = Console.ReadLine();
            command = connection.CreateCommand();
            command.CommandText =
                "SELECT * "
                + "FROM Piece_rechange p, fournisseur f "
                + "WHERE p.siretFournisseur = f.siretFournisseur and f.nomEntreprise = '" + fournisseur + "';";

            reader = command.ExecuteReader();

            string numeroProduit;
            string description;
            string date_intro;
            string date_discont_prod;
            int delai_approvisionnement;
            string numero_produit_fournisseur;
            string siretFournisseur;
            string contact;
            string adresse;
            string libelle;





            while (reader.Read())// parcours ligne par ligne
            {
                numeroProduit = reader.GetString(0);
                description = reader.GetString(1);
                date_intro = reader.GetString(2);
                date_discont_prod = reader.GetString(3);
                delai_approvisionnement = reader.GetInt32(4);
                numero_produit_fournisseur = reader.GetString(5);
                siretFournisseur = reader.GetString(6);
                nomEntreprise = reader.GetString(7);
                contact = reader.GetString(9);
                adresse = reader.GetString(10);
                libelle = reader.GetString(11);

                Console.WriteLine(numeroProduit + " : " + description + " , " + date_intro + " , " + date_discont_prod + " , " + delai_approvisionnement + " , " + numero_produit_fournisseur + " , " + siretFournisseur + " , " + nomEntreprise + " , " + contact + " , " + adresse + " , " + libelle);
            }



            connection.Close();
        }

        static void Exo4(MySqlConnection connection)
        //Gestion des stocks vélo
        {
            connection.Open();

            MySqlCommand command = connection.CreateCommand();
            command.CommandText =
                "SELECT nomB, count(*) as Nombre "
                + "FROM Modele_Bicyclette m "
                + "GROUP BY m.nomB;";

            MySqlDataReader reader;
            reader = command.ExecuteReader();

            string nomB;
            int Nombre = 0;

            while (reader.Read())// parcours ligne par ligne
            {
                nomB = reader.GetString(0);  // récupération de la 1ère colonne (il n'y en a qu'une dans la requête !)
                Nombre = reader.GetInt32(1);
                Console.WriteLine(nomB + " : " + Nombre);
            }

            connection.Close();

            connection.Open();

            Console.WriteLine("Pour quel vélo souhaitez-vous connaitre plus de détails ? (Kilimanjaro, NorthPole, MontBlanc, Hooligan, Orléans, BlueJay, Trail Explorer, Night Hawk, Tierra Verde, Mud Zinger I, Mud Zinger II )");
            string velo = Console.ReadLine();
            command = connection.CreateCommand();
            command.CommandText =
                "SELECT * "
                + "FROM Modele_Bicyclette m "
                + "WHERE m.nomB = '" + velo + "';";

            reader = command.ExecuteReader();

            int numModele;
            int prixUnitaire;
            string ligne_produit;
            string date_intro;
            string date_discont_prod;
            string grandeur;
            string cadre;
            string freins;
            /*string guidon;
            string selle;
            string derailleur_Avant;
            string derailleur_Arrière;
            string roue_Avant;
            string roue_Arrière;
            string reflecteurs;
            string pedalier;
            string ordinateur;
            string panier;*/

            while (reader.Read())// parcours ligne par ligne
            {
                numModele = reader.GetInt32(0);
                nomB = reader.GetString(1);
                prixUnitaire = reader.GetInt32(2);
                ligne_produit = reader.GetString(3);
                date_intro = reader.GetString(4);
                date_discont_prod = reader.GetString(5);
                grandeur = reader.GetString(6);
                cadre = reader.GetString(7);
                freins = reader.GetString(8);

                // Parfois guidon est null et dans ce case .GetString renvoie une erreur

                /*guidon = reader.GetString(9);
                selle = reader.GetString(10);
                derailleur_Avant = reader.GetString(11);
                derailleur_Arrière = reader.GetString(12);
                roue_Avant = reader.GetString(13);
                roue_Arrière = reader.GetString(14);
                reflecteurs = reader.GetString(15);
                pedalier = reader.GetString(16);
                ordinateur = reader.GetString(17);
                panier = reader.GetString(18);*/


                Console.WriteLine(numModele + " : " + nomB + " , " + prixUnitaire + " , " + ligne_produit + " , " + date_intro + " , " + date_discont_prod + " , " + grandeur + " , " + cadre);// + " , " + guidon + " , " + freins + " , " + selle + " , " + derailleur_Avant + " , " + derailleur_Arrière + " , " + roue_Avant + " , " + roue_Arrière + " , " + reflecteurs + " , " + pedalier + " , " + ordinateur + " , " + panier);
            }



            connection.Close();
        }


        static void Exo6(MySqlConnection connection)
        //Gestion des stocks par catégorie de vélo
        {
            connection.Open();

            MySqlCommand command = connection.CreateCommand();
            command.CommandText =
                "SELECT ligne_produit, count(*) as Nombre "
                + "FROM Modele_Bicyclette m "
                + "GROUP BY m.ligne_produit;";

            MySqlDataReader reader;
            reader = command.ExecuteReader();

            string ligne_produit;
            int Nombre = 0;

            while (reader.Read())// parcours ligne par ligne
            {
                ligne_produit = reader.GetString(0);  // récupération de la 1ère colonne (il n'y en a qu'une dans la requête !)
                Nombre = reader.GetInt32(1);
                Console.WriteLine(ligne_produit + " : " + Nombre);
            }

            connection.Close();

            connection.Open();

            Console.WriteLine("Pour quel catégorie de vélo souhaitez-vous connaitre plus de détails ? ( VTT, Vélo de course, Classique, BMX )");
            string categorie = Console.ReadLine();
            command = connection.CreateCommand();
            command.CommandText =
                "SELECT * "
                + "FROM Modele_Bicyclette m "
                + "WHERE m.ligne_produit = '" + categorie + "';";

            reader = command.ExecuteReader();

            int numModele;
            int prixUnitaire;
            string nomB;
            string date_intro;
            string date_discont_prod;
            string grandeur;
            string cadre;
            string freins;
            /*string guidon;
            string selle;
            string derailleur_Avant;
            string derailleur_Arrière;
            string roue_Avant;
            string roue_Arrière;
            string reflecteurs;
            string pedalier;
            string ordinateur;
            string panier;*/

            while (reader.Read())// parcours ligne par ligne
            {
                numModele = reader.GetInt32(0);
                nomB = reader.GetString(1);
                prixUnitaire = reader.GetInt32(2);
                ligne_produit = reader.GetString(3);
                date_intro = reader.GetString(4);
                date_discont_prod = reader.GetString(5);
                grandeur = reader.GetString(6);
                cadre = reader.GetString(7);
                freins = reader.GetString(8);

                // Parfois guidon est null et dans ce case .GetString renvoie une erreur

                /*guidon = reader.GetString(9);
                selle = reader.GetString(10);
                derailleur_Avant = reader.GetString(11);
                derailleur_Arrière = reader.GetString(12);
                roue_Avant = reader.GetString(13);
                roue_Arrière = reader.GetString(14);
                reflecteurs = reader.GetString(15);
                pedalier = reader.GetString(16);
                ordinateur = reader.GetString(17);
                panier = reader.GetString(18);*/


                Console.WriteLine(numModele + " : " + nomB + " , " + prixUnitaire + " , " + ligne_produit + " , " + date_intro + " , " + date_discont_prod + " , " + grandeur + " , " + cadre);// + " , " + guidon + " , " + freins + " , " + selle + " , " + derailleur_Avant + " , " + derailleur_Arrière + " , " + roue_Avant + " , " + roue_Arrière + " , " + reflecteurs + " , " + pedalier + " , " + ordinateur + " , " + panier);
            }



            connection.Close();
        }



        static void Exo7(MySqlConnection connection)
        //Gestion des stocks par grandeur
        {
            connection.Open();

            MySqlCommand command = connection.CreateCommand();
            command.CommandText =
                "SELECT grandeur, count(*) as Nombre "
                + "FROM Modele_Bicyclette m "
                + "GROUP BY m.grandeur;";

            MySqlDataReader reader;
            reader = command.ExecuteReader();

            string grandeur;
            int Nombre = 0;

            while (reader.Read())// parcours ligne par ligne
            {
                grandeur = reader.GetString(0);  // récupération de la 1ère colonne (il n'y en a qu'une dans la requête !)
                Nombre = reader.GetInt32(1);
                Console.WriteLine(grandeur + " : " + Nombre);
            }

            connection.Close();

            connection.Open();

            Console.WriteLine("Pour quel type de vélo souhaitez-vous connaitre plus de détails ? ( Adultes, Jeunes, Hommes, Dames, Filles, Garçons )");
            string type = Console.ReadLine();
            command = connection.CreateCommand();
            command.CommandText =
                "SELECT * "
                + "FROM Modele_Bicyclette m "
                + "WHERE m.grandeur = '" + type + "';";

            reader = command.ExecuteReader();

            int numModele;
            int prixUnitaire;
            string nomB;
            string date_intro;
            string date_discont_prod;
            string ligne_produit;
            string cadre;
            string freins;
            /*string guidon;
            string selle;
            string derailleur_Avant;
            string derailleur_Arrière;
            string roue_Avant;
            string roue_Arrière;
            string reflecteurs;
            string pedalier;
            string ordinateur;
            string panier;*/

            while (reader.Read())// parcours ligne par ligne
            {
                numModele = reader.GetInt32(0);
                nomB = reader.GetString(1);
                prixUnitaire = reader.GetInt32(2);
                ligne_produit = reader.GetString(3);
                date_intro = reader.GetString(4);
                date_discont_prod = reader.GetString(5);
                grandeur = reader.GetString(6);
                cadre = reader.GetString(7);
                freins = reader.GetString(8);

                // Parfois guidon est null et dans ce case .GetString renvoie une erreur

                /*guidon = reader.GetString(9);
                selle = reader.GetString(10);
                derailleur_Avant = reader.GetString(11);
                derailleur_Arrière = reader.GetString(12);
                roue_Avant = reader.GetString(13);
                roue_Arrière = reader.GetString(14);
                reflecteurs = reader.GetString(15);
                pedalier = reader.GetString(16);
                ordinateur = reader.GetString(17);
                panier = reader.GetString(18);*/


                Console.WriteLine(numModele + " : " + nomB + " , " + prixUnitaire + " , " + ligne_produit + " , " + date_intro + " , " + date_discont_prod + " , " + grandeur + " , " + cadre);// + " , " + guidon + " , " + freins + " , " + selle + " , " + derailleur_Avant + " , " + derailleur_Arrière + " , " + roue_Avant + " , " + roue_Arrière + " , " + reflecteurs + " , " + pedalier + " , " + ordinateur + " , " + panier);
            }



            connection.Close();
        }

        static void Exo8(MySqlConnection connection)
        //Gestion des stocks par prix unitaire
        {
            connection.Open();

            MySqlCommand command = connection.CreateCommand();
            command.CommandText =
                "SELECT prixUnitaire, count(*) as Nombre "
                + "FROM Modele_Bicyclette m "
                + "GROUP BY m.prixUnitaire;";

            MySqlDataReader reader;
            reader = command.ExecuteReader();

            int prixUnitaire;
            int Nombre = 0;

            while (reader.Read())// parcours ligne par ligne
            {
                prixUnitaire = reader.GetInt32(0);  // récupération de la 1ère colonne (il n'y en a qu'une dans la requête !)
                Nombre = reader.GetInt32(1);
                Console.WriteLine(prixUnitaire + " : " + Nombre);
            }

            connection.Close();

            connection.Open();

            Console.WriteLine("Pour quel prix maximal de vélo souhaitez-vous connaitre plus de détails ? (en euros)");
            int prix = Convert.ToInt32(Console.ReadLine());
            command = connection.CreateCommand();
            command.CommandText =
                "SELECT * "
                + "FROM Modele_Bicyclette m "
                + "WHERE m.prixUnitaire <= " + prix + ";";

            reader = command.ExecuteReader();

            int numModele;
            string grandeur;
            string nomB;
            string date_intro;
            string date_discont_prod;
            string ligne_produit;
            string cadre;
            string freins;
            /*string guidon;
            string selle;
            string derailleur_Avant;
            string derailleur_Arrière;
            string roue_Avant;
            string roue_Arrière;
            string reflecteurs;
            string pedalier;
            string ordinateur;
            string panier;*/

            while (reader.Read())// parcours ligne par ligne
            {
                numModele = reader.GetInt32(0);
                nomB = reader.GetString(1);
                prixUnitaire = reader.GetInt32(2);
                ligne_produit = reader.GetString(3);
                date_intro = reader.GetString(4);
                date_discont_prod = reader.GetString(5);
                grandeur = reader.GetString(6);
                cadre = reader.GetString(7);
                freins = reader.GetString(8);

                // Parfois guidon est null et dans ce case .GetString renvoie une erreur

                /*guidon = reader.GetString(9);
                selle = reader.GetString(10);
                derailleur_Avant = reader.GetString(11);
                derailleur_Arrière = reader.GetString(12);
                roue_Avant = reader.GetString(13);
                roue_Arrière = reader.GetString(14);
                reflecteurs = reader.GetString(15);
                pedalier = reader.GetString(16);
                ordinateur = reader.GetString(17);
                panier = reader.GetString(18);*/


                Console.WriteLine(numModele + " : " + nomB + " , " + prixUnitaire + " , " + ligne_produit + " , " + date_intro + " , " + date_discont_prod + " , " + grandeur + " , " + cadre);// + " , " + guidon + " , " + freins + " , " + selle + " , " + derailleur_Avant + " , " + derailleur_Arrière + " , " + roue_Avant + " , " + roue_Arrière + " , " + reflecteurs + " , " + pedalier + " , " + ordinateur + " , " + panier);
            }



            connection.Close();
        }

    }
}//class Programm

